# Transfert vers Claude Code — mode d'emploi

Ce dossier reprend **toute la conversation** (sous forme de résumé structuré, la transcription mot à mot n'étant pas exportable) et **tous les livrables**.

## Contenu

| Fichier / dossier | Rôle |
|---|---|
| `CLAUDE.md` | Contexte et règles pour Claude Code (à lire en premier) |
| `01-RESUME-CONVERSATION.md` | Chronologie détaillée : demandes, décisions, corrections |
| `02-ETAT-FINAL-OFFRES.md` | **Version finale** de tous les prix, remises, conditions, calculs |
| `03-LIVRABLES.md` | Inventaire des fichiers et liens publiés |
| `04-POINTS-OUVERTS.md` | Ce qui reste à décider ou à vérifier |
| `livrables/site-offreco/` | Pack pour créer `medy.site/offreco` (page client + zone privée + instructions de sécurité) |
| `livrables/pages-html/` | Les deux pages HTML autonomes (client et interne) |
| `livrables/logo/` | Logo « à plat » de reine-cloud.fr (SVG, PNG, favicons) |
| `livrables/pack-branding-image-corrige/` | Pack d'images de marque reine-cloud.fr (24 fichiers corrigés) |
| `livrables/canvas-sources/` | Sources des deux présentations « planches » (référence) |
| `livrables/scripts/` | Scripts Python qui régénèrent les pages HTML, le logo et les images |

## Comment l'utiliser
1. Décompressez dans un endroit **privé** (pas un dépôt public, pas un dossier servi par le web).
2. Ouvrez Claude Code à la racine de ce dossier (il lira `CLAUDE.md`).
3. Pour le sous-site : collez le contenu de `livrables/site-offreco/PROMPT-A-COLLER.txt`.

## Attention
Le dossier contient des informations confidentielles (coûts, marges, stratégie contractuelle) : ne l'envoyez pas à un client et ne le publiez pas.
