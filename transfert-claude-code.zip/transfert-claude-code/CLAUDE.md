# CLAUDE.md — Contexte du projet « La Maison du CREL » (reprise dans Claude Code)

Langue de travail : **français**. Tutoiement/vouvoiement : l'utilisateur vouvoie ; répondre simplement et sans jargon.

## Qui est l'utilisateur
Consultant en création de solutions IA (agents IA, automatisations) pour des clients ; entreprise **La Maison du CREL** ; site existant `medy.site` déjà construit avec Claude Code. Contact : cazal@medy.site — +33 6 74 20 16 62 (appels et WhatsApp). Il n'est **pas assujetti à la TVA** (mention « TVA non applicable, art. 293 B du CGI » sur ses prix nets).

## Ce qui a été fait dans la conversation d'origine (29 septembre 2026)
1. État des lieux du marché (revente d'hébergement LWS + agents IA), concurrence, chances de réussite.
2. Construction de son offre commerciale et de ses conditions (prix, remises, engagement, heures, cadrage).
3. Deux présentations : **interne** (coûts, marges — confidentielle) et **client** (arguments commerciaux, sans coûts).
4. Des pages HTML autonomes pour chacune, et un pack pour créer le sous-site `medy.site/offreco`.
5. Une autre marque, **reine-cloud.fr** (ex `reine.cloud`) : pack d'images corrigé, puis logo redessiné « à plat » en vecteur.

Détail : voir `01-RESUME-CONVERSATION.md` (chronologie), `02-ETAT-FINAL-OFFRES.md` (chiffres et règles à jour), `03-LIVRABLES.md` (inventaire), `04-POINTS-OUVERTS.md` (reste à décider).

## Règles absolues
1. **Confidentialité** : `livrables/pages-html/presentation-interne.html`, `livrables/site-offreco/private/`, `livrables/site-offreco/docs/NOTES-INTERNES.md`, `livrables/canvas-sources/interne/` et `02-ETAT-FINAL-OFFRES.md` (partie interne) contiennent des coûts, marges et stratégie. **Jamais** dans un dossier public, un dépôt public ou une page client.
2. **Ne modifie aucun prix, remise, durée ou condition** sans l'accord explicite de l'utilisateur. La référence est `02-ETAT-FINAL-OFFRES.md`.
3. **Aucun contenu interne dans la page client** (`livrables/pages-html/offreco-client.html`) : pas de marge, coût de revient, nom du fournisseur d'hébergement.
4. **Ne déploie rien** sans accord ; montre d'abord les tests de sécurité (`livrables/site-offreco/docs/SECURITE.md`).
5. Pas de suivi statistique, cookies ou scripts tiers sans accord. N'invente ni avis clients, ni chiffres, ni références.
6. Les chiffres du calculateur d'usage sont **indicatifs**, pas des engagements.

## Tâche prioritaire à reprendre
Préparer le sous-site `medy.site/offreco` (page client publique) et une zone privée protégée **côté serveur** pour la présentation interne. Instructions complètes : `livrables/site-offreco/CLAUDE.md` et `livrables/site-offreco/PROMPT-A-COLLER.txt`. Commencer par inspecter le site existant et sa protection actuelle, proposer un plan, attendre l'accord.

## Autres tâches possibles
- Intégrer le logo « à plat » (`livrables/logo/`) au site reine-cloud.fr (favicon, en-tête, réseaux sociaux).
- Fixer le seuil d'usage du calculateur client (variable `SEUIL`), après décision de l'utilisateur.
- Mentions légales, CGV et politique de confidentialité (à valider avec un juriste).
