# CLAUDE.md — Sous-site « offreco » pour medy.site

Langue de travail et de communication avec l'utilisateur : **français**.

## Contexte

L'utilisateur dirige **La Maison du CREL** (consultant en solutions IA qui automatisent des tâches répétitives). Il a déjà un site, `medy.site`, construit avec Claude Code, qui comporte déjà une page protégée. Il vend trois formules (socle, agent standard, agent sur mesure) et veut deux choses :

1. une **page publique pour ses clients** : `medy.site/offreco` ;
2. une **présentation interne** (avec ses coûts et ses marges), accessible **uniquement à lui**.

Les deux pages sont déjà écrites, en HTML autonome (CSS et JavaScript inclus, polices Google Fonts) :

- `public/offreco/index.html` : page client ;
- `private/presentation-interne.html` : présentation interne.

## Règles absolues

1. **Ne jamais rendre `presentation-interne.html` accessible sans authentification.** Elle contient des coûts, des marges et une stratégie contractuelle. Si tu as le moindre doute, ne la place pas sur le site et dis-le.
2. **Ne modifie aucun prix, remise, durée ou condition** sans l'accord explicite de l'utilisateur. Les chiffres de référence sont dans `docs/OFFRES-CLIENT.md`.
3. **Aucun contenu interne dans la page client.** Vérifie qu'elle ne contient ni marge, ni coût de revient, ni nom du fournisseur d'hébergement, ni coût d'API brut. Fais une recherche sur les mots « marge », « coût », « LWS », « revient » avant de finir.
4. **Ne déploie rien** sans l'accord de l'utilisateur, après lui avoir montré les résultats des tests de `docs/SECURITE.md`.
5. **Ne mets pas ce pack** (`CLAUDE.md`, `docs/`, `private/`) dans un dossier servi publiquement ni dans un dépôt public.

## Étape 0 — Inspecter avant d'agir

Avant toute modification :

- identifie la technologie du site (statique, Next.js, Astro, PHP, autre) et l'hébergement (Vercel, Netlify, serveur classique, autre) ;
- identifie **comment la page protégée existante est protégée** : vérification côté serveur avant l'envoi du fichier (sûre), ou mot de passe vérifié en JavaScript / fichier dans un dossier public (non sûre) ;
- résume tout cela à l'utilisateur en quelques lignes, puis **propose un plan et attends son accord**.

## Étape 1 — Page publique `/offreco`

- Sers `public/offreco/index.html` à l'adresse `/offreco` (et `/offreco/`), sans changer son contenu ni ses prix.
- Conserve la page autonome. Si le site a un en-tête ou un pied de page communs, ne les ajoute que si l'utilisateur le demande.
- Les contacts sont déjà des liens : e-mail `cazal@medy.site`, téléphone `+33 6 74 20 16 62`, WhatsApp `https://wa.me/33674201662`, site `https://medy.site/offreco`. Vérifie qu'ils fonctionnent.
- Le calculateur d'usage a ses réglages en tête de script : `SEUIL` (0 tant que le seuil d'usage n'est pas fixé), `TAUX` (conversion dollars-euros indicative), `PRIX` (prix publics du fournisseur, en dollars par million de jetons). Ne les change pas sans demander.
- Vérifie : affichage sur mobile et ordinateur, mode sombre, navigation au clavier, absence d'erreur dans la console.
- Suggestion à proposer (sans l'imposer) : héberger les polices localement plutôt que via Google Fonts, pour des raisons de confidentialité des visiteurs européens.
- Ajoute `<meta name="robots" content="index,follow">` seulement si l'utilisateur veut que la page soit référencée ; sinon demande-lui.

## Étape 2 — Zone privée pour la présentation interne

- Crée une zone privée dédiée (par exemple `/interne/…`), **réservée à l'utilisateur**, en réutilisant le mécanisme de protection existant **si et seulement s'il est vérifié côté serveur**. Sinon, propose une protection côté serveur adaptée à l'hébergement (authentification du serveur, middleware, service d'accès devant le domaine).
- Le fichier ne doit **jamais** se trouver dans un dossier servi publiquement (`public/`, `static/`, `assets/`, `dist/` public) sans contrôle d'accès. Sers-le uniquement via la vérification d'accès.
- Utilise un chemin **long et imprévisible**, pas `presentation-interne.html` en clair dans l'URL.
- Ajoute l'en-tête `X-Robots-Tag: noindex, nofollow, noarchive` **et** une balise `<meta name="robots" content="noindex, nofollow, noarchive">`.
- N'ajoute cette zone ni au `sitemap.xml` ni à `robots.txt` (un `Disallow` révélerait le chemin).
- N'ajoute pas de lien vers cette zone depuis une page publique.
- Vérifie que le fichier n'est pas dans l'historique d'un dépôt public. S'il y a un dépôt distant, assure-toi qu'il est privé ou que le fichier est exclu (`.gitignore`).

## Étape 3 — Tests de sécurité (obligatoires)

Fais tous les tests de `docs/SECURITE.md` et **montre les résultats à l'utilisateur** avant tout déploiement.

## Étape 4 — Rapport final

Réponds avec :

1. ce qui a été fait, fichier par fichier ;
2. les résultats de chaque test ;
3. les points restants (voir `docs/A-COMPLETER.md`) ;
4. ce que l'utilisateur doit décider ou fournir.

## Ce que tu ne dois pas faire

- Ne réécris pas les textes commerciaux ni les chiffres.
- N'ajoute pas de suivi statistique, de cookies ni de scripts tiers sans accord.
- N'invente pas d'avis clients, de chiffres ou de références.
- Ne présente pas les chiffres du calculateur comme des engagements : ce sont des estimations indicatives.
