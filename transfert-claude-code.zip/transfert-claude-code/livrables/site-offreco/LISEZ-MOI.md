# Pack « offreco » — La Maison du CREL

Ce dossier contient tout ce qu'il faut pour que Claude Code prépare, sur medy.site, un **sous-site dédié aux offres** :

- une **page publique pour les clients** (`/offreco`) ;
- une **zone privée** pour la présentation interne (coûts, marges, stratégie).

## Contenu

| Chemin | Rôle | Public ? |
|---|---|---|
| `CLAUDE.md` | Instructions complètes pour Claude Code (mission, règles, tests) | non, à ne pas publier |
| `PROMPT-A-COLLER.txt` | Le message à coller dans Claude Code | non |
| `public/offreco/index.html` | Page client autonome (offres, remises, engagement, calculateur d'usage, contact) | **oui** |
| `private/presentation-interne.html` | Présentation interne : coûts, marges, scénarios | **JAMAIS** |
| `docs/OFFRES-CLIENT.md` | Référence des prix et conditions (version client) | non |
| `docs/NOTES-INTERNES.md` | Chiffres internes, hypothèses, points ouverts | **JAMAIS** |
| `docs/SECURITE.md` | Règles de protection et tests à faire | non |
| `docs/A-COMPLETER.md` | Ce qu'il reste à décider ou à renseigner | non |

## Mode d'emploi

1. Décompressez le dossier dans un endroit **privé** (pas dans un dépôt public).
2. Ouvrez Claude Code dans le projet de medy.site et copiez le dossier `offreco-pack` à la racine (ou à côté).
3. Collez le contenu de `PROMPT-A-COLLER.txt`.
4. Ne laissez pas Claude Code déployer avant d'avoir relu ses tests de sécurité (voir `docs/SECURITE.md`).

## Attention

Ce zip contient des informations confidentielles (`private/` et `docs/NOTES-INTERNES.md`). Ne l'envoyez pas à un client, ne le mettez pas dans un dépôt public et ne le déposez pas dans un dossier accessible depuis le web.
