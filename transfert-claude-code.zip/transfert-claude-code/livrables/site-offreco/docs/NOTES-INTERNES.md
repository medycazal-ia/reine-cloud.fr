# Notes internes — CONFIDENTIEL, ne jamais publier

## Fournisseur d'hébergement (revente)
- Programme LWS Reseller (lws.fr) : S 19,99 € HT (23,99 € TTC) — 10 comptes cPanel ; M 39,99 € — 20 ; L 59,99 € — 30 ; XL 99,99 € — 40. Coût par compte ≈ 2 € HT ≈ 2,40 € TTC.
- L'utilisateur n'est pas assujetti à la TVA : la TVA sur ses achats n'est pas récupérable, donc **les coûts se comptent TTC**.
- `lwspanel.fr` n'est pas le programme revendeur (simple domaine enregistré) ; LWS Panel = espace client panel.lws.fr. `lwspanel.host` : lien avec LWS non confirmé. Commander uniquement depuis lws.fr.
- Extras : licence WHMCS en option ; infogérance dès 9,99 € HT l'acte ; matériel Xeon E5 v4 ; reconduction tacite ; satisfait ou remboursé 30 jours.

## Marges (hypothèses de calcul)
- **Socle 19,99 €** : environ 17,59 € par client et par mois après sa part de serveur, soit environ 211 € par an ≈ 4 h à 50 € de l'heure. Les 2 révisions d'1 h par an en consomment la moitié.
- **Agent standard 99 €** : aucune heure de suivi incluse ; l'adaptation est gratuite pour 2 problématiques proches (même outil). Avec un coût d'API d'exemple de 23,40 € par agent : marge 75,60 € (1–2 agents), 55,80 € (3), 45,90 € (4), 36,00 € (5). Une heure non payée à 49 € efface la marge à 5 agents.
- **Sur mesure dès 299 €** : le forfait de 2 h vaut 98 € de temps à 49 € de l'heure ; il reste environ 201 € pour la supervision, le rapport mensuel et l'API.
- **Cadrage 199 €** : à 3 h, environ 66 € de l'heure ; si le client signe, 50 % sont déduits de la mise en place (les heures au-delà de 3 h valent alors 24,50 € nets de l'heure).
- **Contrat minimum sur mesure** : 24 × 299 = 7 176 € + 199 € de cadrage + 1 400,50 € de mise en place = 8 775,50 €.
- Sortie anticipée (exemples à 299 €) : après 3 mois, 21 mensualités = 6 279 € × 75 % ≈ 4 709 € ; après 12 mois, 12 × 299 = 3 588 € × 50 % = 1 794 €.

## Scénario illustratif à 8 clients
4 socle (19,99 €) + 3 socle+agent (118,99 €) + 1 sur mesure (dès 299 €) = environ 736 € par mois ; moins le serveur Reseller S (23,99 € TTC) ≈ **712 € par mois**, soit environ 8 500 € par an, plus 1 500 € de mise en place. Point mort du serveur : 2 clients socle. Hypothèse, avant coûts d'outils, d'API et de temps.

## API (prix publics, page officielle au 29 septembre 2026)
USD par million de jetons (lecture / écriture) : Haiku 4.5 = 1 / 5 ; Sonnet 5.5 = 2 / 10 ; Opus 5.5 = 4 / 20. Taux indicatif 1 $ = 0,87 €. Le coût réel par agent est **à mesurer** (une semaine de test) : la valeur de 23,40 € par agent est une valeur d'exemple.

## Points de vigilance
- **Juridique** : engagement de 24 mois, indemnité de sortie (clause pénale, modérable par un juge si manifestement excessive), reconduction tacite avec préavis de 6 mois (rappel écrit conseillé ; règles plus strictes avec des particuliers). Faire relire par un juriste.
- **Cohérence** : avec les paliers de sortie, l'engagement n'est plus « ferme » au sens strict.
- **TVA** : au-delà du seuil de la franchise en base, la TVA s'appliquera : vérifier le seuil en vigueur auprès de l'administration ou d'un comptable.
- **Prix public vs coût d'usage** : le calculateur client montre un coût d'usage d'environ 4,50 € (valeurs par défaut) à côté d'un prix de 99 € : le rapport est visible. À assumer (valeur = temps gagné, adaptation) ou à masquer.
- **Marge qui fond** avec les remises : plancher conseillé pour les devis à 6 agents et plus : le prix par agent à 5 agents (59,40 €) ou un peu au-dessus.
