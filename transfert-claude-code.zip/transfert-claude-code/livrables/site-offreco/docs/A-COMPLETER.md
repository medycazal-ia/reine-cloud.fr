# À décider ou à renseigner

1. **Seuil d'usage** inclus dans les offres et **prix de l'excédent refacturé** (réglage `SEUIL` dans le calculateur de la page client).
2. **Coûts d'API réels** : mesurer un agent pendant une semaine ; mettre à jour les hypothèses internes.
3. **Juriste** : contrat sur mesure (engagement 24 mois, sortie 75 % / 50 %, reconduction tacite, préavis 6 mois, recette, RGPD, réversibilité) et éventuelles CGV.
4. **Mentions légales** du site (identité, hébergeur, contact) et **politique de confidentialité** : à fournir par l'utilisateur ; à valider avec un juriste.
5. **TVA** : vérifier le seuil de la franchise en base et l'effet d'un dépassement sur les prix.
6. **Agent standard** : confirmer l'absence de frais de mise en place, et l'éventuel engagement.
7. **Interventions** : limite de 3 interventions par mois (forfait de 2 h) : à confirmer.
8. **Hébergement / sauvegardes** : vérifier que « hébergement en France » et « sauvegardes » correspondent bien à ce qui est livré au client.
9. **Référencement** : la page `/offreco` doit-elle être indexée par les moteurs de recherche ?
10. **Zone privée** : choisir le chemin et le mode d'accès (réutiliser la protection existante si elle est vérifiée côté serveur).
