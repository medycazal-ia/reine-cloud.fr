# Offres — référence client (prix nets, TVA non applicable, art. 293 B du CGI)

Cette référence sert à vérifier que la page `public/offreco/index.html` est fidèle. **Ne modifier aucun chiffre sans l'accord de l'utilisateur.**

## Le socle — 19,99 € / mois
Site et e-mails professionnels, hébergement en France, sauvegardes et mises à jour, interlocuteur unique, 2 révisions par an d'environ 1 heure (changements rapides et simples). Soit moins de 0,70 € par jour, 239,88 € par an.

## L'agent standard — 99 € / mois par agent
- Un agent traite **2 problématiques proches sur le même outil**. Un autre outil, ou une 3e problématique, = un autre agent.
- Adaptation **sans frais** si le client envoie lui-même ses problématiques ; pas de frais de mise en place.
- **Audit en visio optionnel** : 1 ou 2 heures, à 49 € de l'heure.
- Aucune heure de suivi incluse ; modifications et suivi : 49 € de l'heure, sur devis.
- Argument : 99 € ≈ l'équivalent d'environ 4 heures de travail d'un salarié ; si l'agent fait gagner plus de 4 heures par mois, il est rentabilisé.

### Remises (suivent les agents actifs, y compris ceux ajoutés plus tard)
| Agents | Remise | Prix mensuel | Par agent | Économie sur un an |
|---|---|---|---|---|
| 1 | 0 % | 99,00 € | 99,00 € | — |
| 2 | 0 % | 198,00 € | 99,00 € | — |
| 3 | 20 % | 237,60 € | 79,20 € | 712,80 € |
| 4 | 30 % | 277,20 € | 69,30 € | 1 425,60 € |
| 5 | 40 % | 297,00 € | 59,40 € | 2 376,00 € |
| 6 et plus | sur devis et négociation | | | |

## Le sur mesure
- **Abonnement : à partir de 299 € / mois** : suivi de l'agent, rapport mensuel d'activité, forfait de **2 h de révisions par mois** (3 interventions maximum, non cumulables).
- **Mise en place : à partir de 1 500 €** (3 niveaux : simple, intermédiaire, avancé, selon outils connectés, sensibilité des données, volume).
- **Cadrage préalable : 199 €**, jusqu'à 3 h ; au-delà 49 € de l'heure. Si le client poursuit, **50 % du cadrage** (heures en plus comprises) sont déduits de la mise en place (99,50 € pour un cadrage de 199 €, soit une mise en place à partir de 1 400,50 €).
- **À la carte : 49 € de l'heure** (heures au-delà du forfait, nouvelles fonctions, options).
- Au-delà d'un plafond d'usage défini au devis, l'excédent est refacturé (**seuil non encore fixé**).

### Engagement
- **24 mois.** Sortie anticipée : **75 % des mensualités restantes avant 6 mois, 50 % à partir de 6 mois.**
- **Renouvellement tacite pour 24 mois** sauf préavis donné **6 mois avant la fin** (donc avant le mois 18).
- Exemple : départ après 12 mois à 299 € : 12 mensualités restantes = 3 588 € ; le client paie 50 % = 1 794 €.
- Recette signée, RGPD, conditions de reprise fixées au contrat.

## Tarif horaire unique : 49 €
Audit en visio, modifications, nouvelles fonctions, heures hors forfait.

## Calculateur d'usage (page client)
Estimation du coût d'usage de l'IA sur les prix publics du fournisseur au 29 septembre 2026 (USD par million de jetons, lecture / écriture) : Haiku 4.5 = 1 / 5 ; Sonnet 5.5 = 2 / 10 ; Opus 5.5 = 4 / 20. Conversion indicative 1 $ = 0,87 €. Estimations : 1 page ≈ 1 000 jetons, consignes ≈ 1 500 jetons par étape, fourchette de 1× à 1,5×.

## Contact
La Maison du CREL — cazal@medy.site — +33 6 74 20 16 62 (appels et WhatsApp) — medy.site/offreco
