# Sécurité de la présentation interne

## Principe

Protéger la page qui contient un lien vers le fichier ne protège pas le fichier. La protection doit être **vérifiée côté serveur, sur le chemin du fichier lui-même**.

## Ce qui protège

- Une authentification côté serveur appliquée au chemin du fichier (authentification du serveur, vérification de session dans le code, service d'accès devant le domaine).

## Ce qui ne protège pas

- Un mot de passe vérifié par JavaScript dans la page : le contenu est déjà envoyé au navigateur.
- Un fichier placé dans un dossier public (`public/`, `static/`, `assets/`) sans contrôle d'accès.
- Un dépôt de code public.
- Un nom de fichier prévisible comme `presentation-interne.html`.

## Tests à réaliser (avec résultats montrés à l'utilisateur)

1. **Sans session** (navigation privée ou `curl` sans cookie), demander l'adresse exacte du fichier : réponse attendue **401, 403 ou redirection vers la connexion**, jamais le contenu.
2. Même test sur : l'adresse du dossier, avec et sans `/` final, avec une autre casse, avec `?x=1`, et avec `/../`.
3. **Avec session valide** : le fichier s'affiche correctement, y compris le calculateur.
4. Dans le dossier de **sortie du site** (build) : vérifier que `presentation-interne.html` n'apparaît **pas** dans les fichiers statiques publics.
5. Vérifier que l'en-tête `X-Robots-Tag: noindex, nofollow, noarchive` est présent et que la page n'est pas dans `sitemap.xml` ni `robots.txt`.
6. Chercher dans l'**historique du dépôt** et sur le **dépôt distant** que le fichier n'y est pas en clair et public.
7. Vérifier qu'aucune page publique ne renvoie vers cette zone.
8. Rechercher dans `public/offreco/index.html` les mots « marge », « coût », « LWS », « revient » : aucun résultat sensible attendu.

## Bonne pratique

Si l'utilisateur n'a pas besoin de consulter la présentation interne depuis plusieurs appareils, la solution la plus sûre est de **ne pas l'héberger** et de la garder en fichier local.
