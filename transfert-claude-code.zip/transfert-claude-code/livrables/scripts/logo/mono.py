# -*- coding: utf-8 -*-
import math, sys
sys.path.insert(0, '/home/claude/logo')
from shapely.geometry import Polygon, LineString, Point, MultiPolygon
from shapely.ops import unary_union
from shapely import affinity
from svgpathtools import parse_path
from geom import *

def pts(d, n=60):
    p = parse_path(d); out = []
    for seg in p:
        for i in range(n if seg.__class__.__name__ in ('CubicBezier', 'QuadraticBezier', 'Arc') else 2):
            t = i / float(n - 1 if seg.__class__.__name__ in ('CubicBezier', 'QuadraticBezier', 'Arc') else 1)
            z = seg.point(t); out.append((z.real, z.imag))
    return out

def poly(d): return Polygon(pts(d)).buffer(0)
def line(d, w): return LineString(pts(d)).buffer(w / 2.0, cap_style=1, join_style=1)
def seg(x1, y1, x2, y2, w): return LineString([(x1, y1), (x2, y2)]).buffer(w / 2.0, cap_style=1)
def mir(g): return affinity.scale(g, xfact=-1, yfact=1, origin=(602, 0))
def both(g): return unary_union([g, mir(g)])
def rhombus(cx, cy, hw, hh, rot=0):
    g = Polygon([(cx, cy - hh), (cx + hw, cy), (cx, cy + hh), (cx - hw, cy)])
    return affinity.rotate(g, rot, origin=(cx, cy)) if rot else g

def to_path(g):
    geoms = list(g.geoms) if isinstance(g, MultiPolygon) else [g]
    d = ''
    for p in geoms:
        if p.is_empty or p.area < 1.5: continue
        for ring in [p.exterior] + list(p.interiors):
            c = list(ring.coords)
            d += 'M' + ' L'.join('%.1f %.1f' % xy for xy in c[:-1]) + 'Z'
    return d

def mono_icon(col):
    # prune + feuille, avec écart autour de la couronne et de la brindille
    band = poly(BAND)
    twig_l = LineString([(300, 400), (392, 448)])
    plum_leaf = unary_union([poly(BODY), poly(LEAF)])
    plum_leaf = plum_leaf.difference(unary_union([band.buffer(11), twig_l.buffer(27, cap_style=1)]))
    plum_leaf = plum_leaf.difference(unary_union([line(CLEFT, 12), line(LEAF_RIB, 7)]))
    extras = unary_union([twig_l.buffer(16, cap_style=1), line(STALK, 9), seg(552, 505, 584, 600, 22)])
    extras = extras.difference(band.buffer(11))
    base = unary_union([plum_leaf, extras])
    # couronne
    rear = both(poly(REAR_L)); front = poly(front_path()); tips = both(poly(TIP_L))
    crown = unary_union([rear, front, tips, band])
    cuts = [both(line(ARCH_L, 5)), line(BAND_TOP, 5), line(BAND_MID, 3),
            seg(601, 196, 601, 300, 4), both(seg(572, 232, 601, 290, 4)),
            rhombus(601, 138, 27, 37), rhombus(601, 342, 33, 46), rhombus(601, 490, 34, 15),
            both(rhombus(478, 486, 17, 11)), both(rhombus(393, 394, 12, 22, -24)), both(rhombus(394, 496, 8, 14)),
            both(Polygon([(298, 222), (318, 231), (318, 262), (300, 254)])),
            both(line("M302 262 L341 268", 5))]
    crown = crown.difference(unary_union(cuts))
    # symbole orbite
    cloud = LineString(pts(orbit_paths())).buffer(5, cap_style=1, join_style=1)
    ring = LineString(list(Point(0, 0).buffer(1, 64).exterior.coords))
    ring = affinity.scale(ring, 112, 30, origin=(0, 0)); ring = affinity.rotate(ring, -16, origin=(0, 0)); ring = affinity.translate(ring, 835, 148)
    ring = ring.buffer(4.5, cap_style=1)
    ball = Point(932, 54).buffer(20, 48)
    arm = line("M902 74 Q916 66 924 66", 8)
    orb = unary_union([cloud, ring, ball, arm])
    allg = unary_union([base, crown, orb])
    return '<path fill="%s" fill-rule="evenodd" d="%s"/>' % (col, to_path(allg))
