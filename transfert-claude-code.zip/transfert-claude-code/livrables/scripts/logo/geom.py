# -*- coding: utf-8 -*-
# Géométrie du logo (repère 1000 x 1210) ; symétrie de la couronne autour de x = 602
MX = 1204
def mx(x): return MX - x

PAL = dict(
    plum_l="#A9C452", plum_r="#8DB040", plum_shade="#6E8F2F", plum_hi_l="#C5D97A", plum_hi_r="#A9C452",
    cleft="#A6C19A", spot_l="#D2E28F", spot_d="#6B5A22",
    stem="#7B6A22", twig="#755A3C", twig_cap="#A98B67", stalk="#7FA55E",
    leaf_d="#5E8A47", leaf_l="#8CB577", rib="#C7D9B3",
    gold="#D9A93A", gold_l="#F3D77A", gold_d="#A97B1E", gold_dd="#8C6416", gold_back="#B7861F", gold_hi="#FBEBA6",
    em="#1E9A5C", em_l="#47C482", em_d="#0F6B3D",
)

def gem(cx, cy, hw, hh, rot=0, frame=True, P=PAL):
    t = 'transform="rotate(%s %s %s)"' % (rot, cx, cy) if rot else ''
    s = '<g %s>' % t
    if frame:
        fw, fh = hw * 1.32, hh * 1.28
        s += '<path d="M%s %s L%s %s L%s %s L%s %s Z" fill="%s" stroke="%s" stroke-width="4" stroke-linejoin="round"/>' % (
            cx, cy - fh, cx + fw, cy, cx, cy + fh, cx - fw, cy, P['gold_l'], P['gold_d'])
    s += '<path d="M%s %s L%s %s L%s %s L%s %s Z" fill="%s"/>' % (cx, cy - hh, cx + hw, cy, cx, cy + hh, cx - hw, cy, P['em'])
    s += '<path d="M%s %s L%s %s L%s %s Z" fill="%s"/>' % (cx, cy - hh, cx + hw, cy, cx, cy, P['em_l'])
    s += '<path d="M%s %s L%s %s L%s %s Z" fill="%s"/>' % (cx - hw, cy, cx, cy, cx, cy + hh, P['em_d'])
    return s + '</g>'

def gem_shape(cx, cy, hw, hh, rot=0, frame=True):
    """silhouette d'une gemme (pour les masques du mode une couleur)"""
    t = 'transform="rotate(%s %s %s)"' % (rot, cx, cy) if rot else ''
    hw2, hh2 = (hw, hh)
    return '<path %s d="M%s %s L%s %s L%s %s L%s %s Z"/>' % (t, cx, cy - hh2, cx + hw2, cy, cx, cy + hh2, cx - hw2, cy)

# ---------- éléments ----------
BODY = "M600 522 C760 505 958 640 958 850 C958 1020 800 1168 600 1168 C400 1168 240 1030 240 850 C240 660 430 510 600 522 Z"
RIGHT_LOBE = "M556 588 C470 690 435 850 470 1030 C490 1100 525 1140 600 1168 C800 1168 958 1020 958 850 C958 640 760 505 600 522 Z"
RIGHT_SHADE = "M958 850 C958 1020 800 1168 600 1168 C760 1150 905 1030 908 850 C910 710 835 600 735 548 C880 596 958 700 958 850 Z"
LEFT_SHADE = "M240 850 C240 1030 400 1168 600 1168 C470 1140 330 1040 318 850 C310 700 380 600 470 548 C320 590 240 700 240 850 Z"
HI_L = "M318 700 C318 640 360 600 420 585 C378 630 362 700 372 770 C340 760 318 740 318 700 Z"
HI_R = "M590 640 C640 610 720 610 770 640 C720 632 650 642 610 690 C595 675 588 655 590 640 Z"
CLEFT = "M556 588 C470 690 435 850 470 1030 C490 1100 520 1138 556 1160"
LEAF = "M300 497 C250 470 130 470 70 570 C45 615 40 690 45 757 C120 735 250 660 300 497 Z"
LEAF_L = "M298 500 C220 560 120 660 50 750 C120 735 250 660 300 497 Z"
LEAF_RIB = "M298 500 C222 562 122 662 52 750"
STALK = "M370 452 Q334 470 300 498"

FRONT_L = "M341 268 C360 335 420 388 462 392 C505 393 550 300 585 200 L601 190"
def front_path():
    l = [(341,268),(360,335),(420,388),(462,392),(505,393),(550,300),(585,200),(601,190)]
    p = "M341 268 C360 335 420 388 462 392 C505 393 550 300 585 200 L601 190 L%d 200 C%d 300 %d 393 %d 392 C%d 388 %d 335 %d 268 L816 440 L388 440 Z" % (
        mx(585), mx(550), mx(505), mx(462), mx(420), mx(360), mx(341))
    return p
ARCH_L = "M344 268 C360 335 420 388 462 392 C505 393 550 300 585 200"
REAR_L = "M455 222 L483 262 L512 345 L505 410 L438 410 L440 262 Z"
REAR_HI_L = "M455 222 L440 262 L438 410 L458 410 L462 300 Z"
BAND = "M385 442 Q602 452 819 442 L823 520 Q602 571 381 524 Z"
BAND_TOP = "M385 442 Q602 452 819 442"
BAND_BOT = "M381 524 Q602 571 823 520"
BAND_MID = "M383 484 Q602 512 821 482"
TIP_L = "M292 207 L326 197 L344 222 L341 268 L302 262 Z"

def orbit_paths():
    cloud = "M772 150 C745 142 748 100 780 95 C785 68 830 55 852 78 C872 62 906 76 898 106 C926 116 916 152 880 149"
    return cloud
