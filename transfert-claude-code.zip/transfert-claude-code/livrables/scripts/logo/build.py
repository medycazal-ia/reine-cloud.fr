# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, '/home/claude/logo')
from geom import *
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

F = '/home/claude/fonts/'
_fonts = {}
def font(name):
    if name not in _fonts: _fonts[name] = TTFont(F + name)
    return _fonts[name]

def text_path(fname, text, size, x, y, spacing=0.0):
    """contours vectoriels du texte (aucune police requise à l'affichage)"""
    f = font(fname); upm = f['head'].unitsPerEm; s = size / upm
    cmap = f.getBestCmap(); gs = f.getGlyphSet(); hmtx = f['hmtx']
    d = ''; cx = x
    for ch in text:
        g = cmap[ord(ch)]
        pen = SVGPathPen(gs)
        gs[g].draw(TransformPen(pen, (s, 0, 0, -s, cx, y)))
        d += pen.getCommands()
        cx += hmtx[g][0] * s + spacing
    return d, cx - x

# ---------------------------------------------------------------- icône
def mirror(content):
    return '<g>%s</g><g transform="translate(%d 0) scale(-1 1)">%s</g>' % (content, MX, content)

def icon_color(P=PAL):
    s = ''
    # feuille, brindille
    s += '<path d="%s" fill="%s"/>' % (LEAF, P['leaf_d'])
    s += '<path d="%s" fill="%s"/>' % (LEAF_L, P['leaf_l'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="7" stroke-linecap="round"/>' % (LEAF_RIB, P['rib'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round"/>' % (STALK, P['stalk'])
    s += '<path d="M300 400 L392 448" stroke="%s" stroke-width="32" stroke-linecap="round" fill="none"/>' % P['twig']
    s += '<circle cx="298" cy="399" r="14" fill="%s"/>' % P['twig_cap']
    s += '<path d="M330 412 L336 432 M352 424 L358 444" stroke="#5E4429" stroke-width="4" stroke-linecap="round"/>'
    # prune
    s += '<path d="%s" fill="%s"/>' % (BODY, P['plum_l'])
    s += '<path d="%s" fill="%s"/>' % (LEFT_SHADE, "#94B043")
    s += '<path d="%s" fill="%s"/>' % (RIGHT_LOBE, P['plum_r'])
    s += '<path d="%s" fill="%s"/>' % (RIGHT_SHADE, P['plum_shade'])
    s += '<path d="%s" fill="%s"/>' % (HI_L, P['plum_hi_l'])
    s += '<path d="%s" fill="%s"/>' % (HI_R, P['plum_hi_r'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round"/>' % (CLEFT, P['cleft'])
    for (x, y) in [(690,700),(765,735),(650,790),(830,800),(715,850),(560,760),(790,930),(640,980)]:
        s += '<circle cx="%d" cy="%d" r="5" fill="%s"/>' % (x, y, P['spot_l'])
    for (x, y) in [(560,910),(725,1025),(808,975)]:
        s += '<circle cx="%d" cy="%d" r="5" fill="%s"/>' % (x, y, P['spot_d'])
    s += '<path d="M552 505 L584 600" stroke="%s" stroke-width="22" stroke-linecap="round" fill="none"/>' % P['stem']
    # couronne : pointes arrière
    s += mirror('<path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (REAR_L, P['gold_back'], REAR_HI_L, P['gold']))
    # corps avant
    s += '<path d="%s" fill="%s"/>' % (front_path(), P['gold'])
    # zone ajourée (treillis) et volutes
    s += '<path d="M601 196 L601 300 M572 232 L601 290 L630 232 M556 262 L601 300 L646 262" stroke="%s" stroke-width="4" fill="none" stroke-linecap="round"/>' % P['gold_l']
    curls = ''
    for (x, y) in [(414,412),(468,420),(526,414)]:
        curls += '<circle cx="%d" cy="%d" r="13" fill="none" stroke="%s" stroke-width="5"/>' % (x, y, P['gold_l'])
    s += curls + '<g transform="translate(%d 0) scale(-1 1)">%s</g>' % (MX, curls)
    # arche (bord clair)
    s += mirror('<path d="%s" fill="none" stroke="%s" stroke-width="13" stroke-linecap="round"/><path d="%s" fill="none" stroke="%s" stroke-width="4" transform="translate(0 15)" stroke-linecap="round"/>' % (ARCH_L, P['gold_l'], ARCH_L, P['gold_dd']))
    # pointes latérales + gemmes
    s += mirror('<path d="%s" fill="%s" stroke="%s" stroke-width="4" stroke-linejoin="round"/>' % (TIP_L, P['gold_l'], P['gold_d']))
    s += mirror('<path d="M298 222 L318 231 L318 262 L300 254 Z" fill="%s"/><path d="M298 222 L318 231 L318 246 L300 238 Z" fill="%s"/>' % (P['em'], P['em_l']))
    s += mirror(gem(393, 394, 12, 22, rot=-24, frame=False, P=P))
    # pointe centrale + grande gemme
    s += gem(601, 138, 27, 37, P=P)
    s += gem(601, 342, 33, 46, P=P)
    # bandeau
    s += '<path d="%s" fill="%s"/>' % (BAND, P['gold'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round"/>' % (BAND_TOP, P['gold_hi'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="3"/>' % (BAND_MID, P['gold_dd'])
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="7" stroke-linecap="round"/>' % (BAND_BOT, P['gold_d'])
    s += mirror(gem(478, 486, 17, 11, P=P))
    s += gem(601, 490, 34, 15, P=P)
    s += mirror('<circle cx="536" cy="483" r="5" fill="%s"/>' % P['gold_hi'])
    s += mirror(gem(394, 496, 8, 14, P=P))
    # symbole nuage + orbite
    s += orbit(P['gold'])
    return s

def orbit(col):
    s = '<g fill="none" stroke="%s" stroke-linecap="round" stroke-linejoin="round">' % col
    s += '<path d="%s" stroke-width="10"/>' % orbit_paths()
    s += '<ellipse cx="835" cy="148" rx="112" ry="30" transform="rotate(-16 835 148)" stroke-width="9"/>'
    s += '</g><circle cx="932" cy="54" r="20" fill="%s"/>' % col
    s += '<path d="M902 74 Q916 66 924 66" stroke="%s" stroke-width="8" stroke-linecap="round" fill="none"/>' % col
    return s

def icon_mono_old(col):
    """une couleur, avec détails évidés (transparents) grâce à des masques"""
    uid = 'm' + col.strip('#')
    # détails à évider dans la prune / feuille
    cut_plum = ('<path d="%s" stroke="#000" stroke-width="12" fill="none" stroke-linecap="round"/>' % CLEFT
                + '<path d="%s" stroke="#000" stroke-width="7" fill="none" stroke-linecap="round"/>' % LEAF_RIB
                # écart autour de la couronne et de la brindille
                + '<path d="%s" fill="#000" stroke="#000" stroke-width="20" stroke-linejoin="round"/>' % BAND
                + '<path d="M300 400 L392 448" stroke="#000" stroke-width="52" stroke-linecap="round"/>')
    s = '<defs><mask id="%sa" maskUnits="userSpaceOnUse" x="0" y="0" width="1000" height="1210"><rect width="1000" height="1210" fill="#fff"/>%s</mask>' % (uid, cut_plum)
    cut_crown = (mirror('<path d="%s" stroke="#000" stroke-width="5" fill="none"/>' % ARCH_L)
                 + mirror('<path d="%s" stroke="#000" stroke-width="5" fill="none"/>' % 'M302 262 L341 268')
                 + '<path d="%s" stroke="#000" stroke-width="5" fill="none"/>' % BAND_TOP
                 + '<path d="M601 196 L601 300 M572 232 L601 290 L630 232" stroke="#000" stroke-width="4" fill="none"/>'
                 + gem_shape(601, 138, 27, 37) + gem_shape(601, 342, 33, 46) + gem_shape(601, 490, 34, 15)
                 + mirror(gem_shape(478, 486, 17, 11) + gem_shape(393, 394, 12, 22, rot=-24) + gem_shape(394, 496, 8, 14)
                          + '<path d="M298 222 L318 231 L318 262 L300 254 Z"/>'))
    s += '<mask id="%sb" maskUnits="userSpaceOnUse" x="0" y="0" width="1000" height="1210"><rect width="1000" height="1210" fill="#fff"/><g fill="#000">%s</g></mask></defs>' % (uid, cut_crown)
    s += '<g mask="url(#%sa)" fill="%s">' % (uid, col)
    s += '<path d="%s"/><path d="%s"/>' % (LEAF, BODY)
    s += '<path d="M300 400 L392 448" stroke="%s" stroke-width="32" stroke-linecap="round" fill="none"/>' % col
    s += '<path d="%s" fill="none" stroke="%s" stroke-width="9" stroke-linecap="round"/>' % (STALK, col)
    s += '<path d="M552 505 L584 600" stroke="%s" stroke-width="22" stroke-linecap="round" fill="none"/>' % col
    s += '</g>'
    s += '<g mask="url(#%sb)" fill="%s">' % (uid, col)
    s += mirror('<path d="%s"/>' % REAR_L)
    s += '<path d="%s"/>' % front_path()
    s += mirror('<path d="%s"/>' % TIP_L)
    s += '<path d="%s"/>' % BAND
    s += '</g>'
    s += orbit(col)
    return s

from mono import mono_icon as icon_mono
ICON_W, ICON_H, ICON_X0, ICON_Y0 = 922, 1142, 38, 28   # emprise du dessin

def place_icon(inner, x, y, height):
    sc = height / ICON_H
    return '<g transform="translate(%.2f %.2f) scale(%.4f) translate(%d %d)">%s</g>' % (x, y, sc, -ICON_X0, -ICON_Y0, inner), ICON_W * sc

# ---------------------------------------------------------------- textes
NAME_B, NAME_L, TAG = 'reine', '-cloud.fr', 'Hébergement · Cloud · IA · Souveraineté'
def wordmark(cx, base, size, c_b, c_l, align='center', x=0):
    wb = text_path('Montserrat-Bold.ttf', NAME_B, size, 0, 0)[1]
    wl = text_path('Montserrat-Regular.ttf', NAME_L, size, 0, 0)[1]
    tot = wb + wl
    x0 = cx - tot / 2 if align == 'center' else x
    d1, _ = text_path('Montserrat-Bold.ttf', NAME_B, size, x0, base)
    d2, _ = text_path('Montserrat-Regular.ttf', NAME_L, size, x0 + wb, base)
    return '<path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (d1, c_b, d2, c_l), tot

def tagline(cx, base, size, col, align='center', x=0):
    w = text_path('Montserrat-Regular.ttf', TAG, size, 0, 0)[1]
    x0 = cx - w / 2 if align == 'center' else x
    d, _ = text_path('Montserrat-Regular.ttf', TAG, size, x0, base)
    return '<path d="%s" fill="%s"/>' % (d, col), w

def svg(w, h, body, title, bg=None):
    r = '<rect width="%d" height="%d" fill="%s"/>' % (w, h, bg) if bg else ''
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s">\n<title>%s</title>\n%s%s\n</svg>\n'
            % (w, h, w, h, title, title, r, body))

THEMES = {
    'clair':  dict(b='#491E65', l='#6B3878', t='#7A6A50', bg=None),
    'sombre': dict(b='#F1E8F8', l='#CBA9E3', t='#D8CDB8', bg=None),
}

def stacked(theme, mono=None, bg=None):
    W, H = 1400, 950
    icon_inner = icon_mono(mono) if mono else icon_color()
    ic, iw = place_icon(icon_inner, 700 - ICON_W * (560 / ICON_H) / 2, 30, 560)
    c = THEMES[theme]
    cb, cl, ct = (mono, mono, mono) if mono else (c['b'], c['l'], c['t'])
    wm, _ = wordmark(700, 790, 168, cb, cl)
    tg, _ = tagline(700, 880, 48, ct)
    return svg(W, H, ic + wm + tg, 'reine-cloud.fr', bg), (W, H)

def horizontal(theme, mono=None, bg=None):
    H = 420
    icon_inner = icon_mono(mono) if mono else icon_color()
    ic, iw = place_icon(icon_inner, 44, 40, 340)
    c = THEMES[theme]
    cb, cl, ct = (mono, mono, mono) if mono else (c['b'], c['l'], c['t'])
    x = 44 + iw + 50
    wm, tw = wordmark(0, 232, 126, cb, cl, align='left', x=x)
    tg, tgw = tagline(0, 300, 37, ct, align='left', x=x + 4)
    W = int(x + max(tw, tgw) + 50)
    return svg(W, H, ic + wm + tg, 'reine-cloud.fr', bg), (W, H)

def icon_only(theme, mono=None, bg=None):
    S = 1000
    inner = icon_mono(mono) if mono else icon_color()
    ic, iw = place_icon(inner, 500 - ICON_W * (860 / ICON_H) / 2, 70, 860)
    return svg(S, S, ic, 'reine-cloud.fr - icône', bg), (S, S)

if __name__ == '__main__':
    out = '/home/claude/logo/out'; os.makedirs(out + '/svg', exist_ok=True)
    files = {}
    files['logo-empile-couleur.svg'] = stacked('clair')
    files['logo-empile-fond-sombre.svg'] = stacked('sombre')
    files['logo-horizontal-couleur.svg'] = horizontal('clair')
    files['logo-horizontal-fond-sombre.svg'] = horizontal('sombre')
    files['icone-couleur.svg'] = icon_only('clair')
    files['logo-empile-1-couleur-violet.svg'] = stacked('clair', mono='#491E65')
    files['logo-empile-1-couleur-blanc.svg'] = stacked('sombre', mono='#FFFFFF')
    files['icone-1-couleur-violet.svg'] = icon_only('clair', mono='#491E65')
    files['icone-1-couleur-blanc.svg'] = icon_only('sombre', mono='#FFFFFF')
    for n, (s, size) in files.items():
        open('%s/svg/%s' % (out, n), 'w', encoding='utf-8').write(s)
    print(list(files))
