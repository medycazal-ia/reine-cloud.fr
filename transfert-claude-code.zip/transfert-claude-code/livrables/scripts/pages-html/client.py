# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,'/home/claude/gen')
from base import page, S

EMAIL="cazal@medy.site"
TEL="+33 6 74 20 16 62"
TEL_HREF="tel:+33674201662"
WA="https://wa.me/33674201662"
SITE="https://medy.site/offreco"
MAIL_HREF="mailto:cazal@medy.site?subject=Demande%20d%27information%20-%20La%20Maison%20du%20CREL"

TVA='<p class="note">Prix nets : TVA non applicable, article 293 B du CGI.</p>'
b=[]

b.append(S("formules","Nos formules","La Maison du CREL · Automatisation par l'IA","""
<h1>Moins de tâches répétitives, plus de temps pour votre métier.</h1>
<p class="lead">Des agents IA adaptés à vos outils, un site et des e-mails à votre image, et un seul interlocuteur. Des prix clairs, expliqués un par un.</p>
<div class="grid g3">
<div class="card"><div class="tag">Le socle</div><div class="price">19,99 € <small>/ mois</small></div><p>Votre site, vos e-mails et votre hébergement, entretenus pour vous.</p></div>
<div class="card accent"><div class="tag">L'agent standard</div><div class="price">99 € <small>/ mois</small></div><p>Un agent prêt à prendre en charge vos tâches répétitives.</p></div>
<div class="card dark"><div class="tag">Le sur mesure</div><div class="price">dès 299 € <small>/ mois</small></div><p>Un agent conçu pour votre métier, suivi chaque mois.</p></div>
</div>
<div class="ctas"><a class="btn" href="%s">Nous écrire</a><a class="btn ghost" href="%s" target="_blank" rel="noopener">WhatsApp</a></div>
%s""" % (MAIL_HREF, WA, TVA)))

b.append(S("socle","Le socle","Le socle","""
<h2>Une base solide et entretenue, pour 19,99 € par mois.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Ce qui est inclus</div>
<ul class="list">
<li><strong>Un site et des e-mails professionnels</strong> à votre nom.</li>
<li><strong>Un hébergement en France</strong>, géré pour vous.</li>
<li><strong>Des sauvegardes et des mises à jour</strong>, sans que vous ayez à y penser.</li>
<li><strong>Un interlocuteur unique</strong> pour toute question.</li>
<li><strong>Deux révisions par an</strong> d'environ une heure, pour ajuster votre site avec vous : changements rapides et simples.</li>
</ul></div>
<div style="display:flex;flex-direction:column;gap:20px">
<div class="card dark"><div class="tag">Ce que ça représente</div><h3>Moins de 0,70 € par jour</h3><p>Soit 239,88 € par an pour un site qui reste à jour et des e-mails qui fonctionnent.</p></div>
<div class="card"><h3>Pourquoi tout confier au même prestataire</h3><p>Vous n'avez plus à coordonner un hébergeur, une messagerie et un créateur de site : une seule personne répond de l'ensemble.</p></div>
</div></div>
%s""" % TVA, alt=True))

b.append(S("agent","L'agent standard","L'agent standard","""
<h2>99 € par mois : l'équivalent d'environ 4 heures de travail d'un salarié.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Comment ça se passe</div>
<ul class="list">
<li><strong>Vous nous envoyez vos problématiques.</strong> Un agent en traite deux proches, sur le même outil.</li>
<li><strong>Nous vous livrons l'agent adapté</strong>, sans frais de mise en place.</li>
<li><strong>Un audit en visio est possible</strong> si vous préférez en parler : 1 ou 2 heures, à 49 € de l'heure.</li>
<li><strong>Un autre outil ?</strong> C'est un autre agent, avec une remise dès le troisième.</li>
</ul></div>
<div class="card dark"><div class="tag">Le calcul pour vous</div>
<h3>Si votre agent vous fait gagner plus de 4 heures par mois, il est rentabilisé.</h3>
<p>Comptez le temps que vous ou vos collaborateurs passez chaque mois sur ces tâches répétitives. Au-delà de 4 heures, l'agent vous rapporte du temps, et donc de l'argent.</p>
<p>Une fois en place, il traite vos demandes de la même manière à chaque fois.</p></div>
</div>
<div class="grid g2">
<div class="good"><strong>Un prix simple.</strong> 99 € par mois et par agent, sans frais de mise en place.</div>
<div class="good"><strong>Des évolutions à la demande.</strong> Modifications et suivi supplémentaires : 49 € de l'heure, devis à l'appui.</div>
</div>
%s""" % TVA))

b.append(S("remises","Remises","Remises sur les agents standard","""
<h2>Plus vous automatisez, moins chaque agent coûte : jusqu'à 40 % de remise.</h2>
<div class="tblwrap"><table>
<thead><tr><th>Agents</th><th>Remise</th><th>Prix mensuel</th><th>Par agent</th><th>Économie sur un an</th></tr></thead>
<tbody>
<tr><td><strong>1 agent</strong></td><td>0 %</td><td>99,00 €</td><td>99,00 €</td><td>Tarif de base</td></tr>
<tr><td><strong>2 agents</strong></td><td>0 %</td><td>198,00 €</td><td>99,00 €</td><td>Tarif de base</td></tr>
<tr><td><strong>3 agents</strong></td><td class="pos">20 %</td><td>237,60 €</td><td>79,20 €</td><td class="pos">712,80 €</td></tr>
<tr><td><strong>4 agents</strong></td><td class="pos">30 %</td><td>277,20 €</td><td>69,30 €</td><td class="pos">1 425,60 €</td></tr>
<tr><td><strong>5 agents</strong></td><td class="pos">40 %</td><td>297,00 €</td><td>59,40 €</td><td class="pos">2 376,00 €</td></tr>
<tr><td><strong>6 agents et +</strong></td><td colspan="4" class="pos">Sur devis et négociation : parlons de votre projet</td></tr>
</tbody></table></div>
<div class="grid g3">
<div class="good"><strong>Un exemple.</strong> Avec 5 agents, vous payez 297 € par mois : l'équivalent d'environ 20 heures de travail d'un salarié, à raison de 4 heures par agent.</div>
<div class="good"><strong>Ce qu'est un agent.</strong> Deux problématiques proches sur le même outil. Un autre outil, c'est un autre agent.</div>
<div class="good"><strong>Un tarif qui vous suit.</strong> La remise correspond au nombre d'agents actifs, y compris ceux que vous ajoutez plus tard.</div>
</div>
<p class="note">Prix nets mensuels : TVA non applicable, article 293 B du CGI. Économie calculée par rapport à 99 € par agent, sur 12 mois.</p>""", alt=True))

b.append(S("surmesure","Le sur mesure","Le sur mesure","""
<h2>Un agent conçu pour votre métier, suivi chaque mois.</h2>
<div class="grid g3">
<div class="card dark"><div class="tag">Abonnement mensuel</div><div class="price">à partir de 299 € <small>/ mois</small></div><p>Suivi de l'agent, rapport mensuel et 2 heures de révisions incluses.</p></div>
<div class="card dark"><div class="tag">Mise en place</div><div class="price">à partir de 1 500 €</div><p>Le prix exact dépend du nombre d'outils connectés, de la sensibilité de vos données et du volume à traiter : trois niveaux, simple, intermédiaire ou avancé.</p></div>
<div class="card accent"><div class="tag">Cadrage préalable</div><div class="price">199 €</div><p>Jusqu'à 3 heures pour définir ensemble le besoin, les outils, les données et les critères de réussite.</p></div>
</div>
<div class="callout"><b>Le cadrage vous engage à peu.</b> Si vous poursuivez, 50 % du cadrage sont déduits de la mise en place : pour un cadrage de 199 €, 99,50 € en moins, soit une mise en place à partir de 1 400,50 €.</div>
<div class="grid g2">
<div class="card"><div class="tag">Chaque mois, vous avez</div><ul class="list"><li>Un agent supervisé et corrigé si besoin.</li><li>Un rapport mensuel d'activité.</li><li>Jusqu'à 2 heures de révisions, en 3 interventions au maximum, non reportables.</li></ul></div>
<div class="card"><div class="tag">À la carte, si besoin</div><ul class="list"><li>Heures supplémentaires, nouvelles fonctions et options : 49 € de l'heure, sur devis.</li><li>Heures de cadrage au-delà de 3 h : 49 € de l'heure, également déduites à 50 % de la mise en place.</li><li>Au-delà d'un plafond d'usage défini au devis, l'excédent est refacturé.</li></ul></div>
</div>
<div class="grid g4 steps">
<div class="step"><h3>1 · Cadrage</h3><p class="note">On définit le besoin.</p></div>
<div class="step"><h3>2 · Construction</h3><p class="note">On conçoit et on teste.</p></div>
<div class="step"><h3>3 · Validation</h3><p class="note">Vous signez ce qui est livré.</p></div>
<div class="step"><h3>4 · Suivi mensuel</h3><p class="note">On l'améliore avec vous.</p></div>
</div>
@@TVA@@""".replace("@@TVA@@", TVA)))

b.append(S("engagement","Engagement","Sur mesure · engagement","""
<h2>Un engagement de 24 mois, et des règles connues d'avance.</h2>
<div class="card"><p><strong>Pourquoi 24 mois ?</strong> Un agent sur mesure prend de la valeur avec le temps : il s'affine avec vos retours et vos usages. L'engagement garantit un suivi et une amélioration continus, dans la durée.</p></div>
<div class="split">
<div class="c" style="flex:1 1 25%"><span class="tag">Sortie avant 6 mois</span><strong>75 % des mensualités restantes</strong></div>
<div class="b" style="flex:1 1 75%"><span class="tag">Sortie à partir de 6 mois</span><strong>50 % des mensualités restantes</strong></div>
</div>
<div class="grid g2">
<div class="card"><p><strong style="color:var(--teal)">Un exemple.</strong> Vous quittez le contrat après 12 mois, avec un abonnement à 299 € : il reste 12 mensualités, soit 3 588 €. Vous réglez 50 %, soit <strong>1 794 €</strong>.</p></div>
<div class="card"><p><strong style="color:var(--teal)">Renouvellement.</strong> À l'échéance, le contrat se renouvelle pour 24 mois, sauf préavis donné 6 mois avant la fin, donc avant le mois 18.</p></div>
</div>
<div class="grid g2">
<div class="good"><strong>Vous validez ce qui est livré.</strong> Une recette signée précise ce que fait l'agent, avant le démarrage du suivi.</div>
<div class="good"><strong>Vos données restent les vôtres.</strong> Le traitement respecte le RGPD, et les conditions de reprise en fin de contrat sont fixées au contrat.</div>
</div>
<p class="note">Montants nets : TVA non applicable, article 293 B du CGI. Les conditions détaillées figurent au contrat.</p>""", alt=True))

b.append(S("usage","Estimez votre consommation","Estimez votre consommation","""
<h2>Un coût d'usage transparent, calculé sur les prix publics du fournisseur.</h2>
<div class="calc">
<div class="card">
<div class="field"><div class="row"><label for="c-dem">Demandes traitées par mois</label><output id="o-dem"></output></div><input id="c-dem" type="range" min="0" max="3000" step="10" value="200"></div>
<div class="field"><div class="row"><label for="c-pin">Pages de documents lues par demande</label><output id="o-pin"></output></div><input id="c-pin" type="range" min="0" max="20" step="0.5" value="2"></div>
<div class="field"><div class="row"><label for="c-eta">Étapes de traitement par demande</label><output id="o-eta"></output></div><input id="c-eta" type="range" min="1" max="8" step="1" value="3"></div>
<div class="field"><div class="row"><label for="c-pout">Pages écrites par demande</label><output id="o-pout"></output></div><input id="c-pout" type="range" min="0" max="5" step="0.5" value="0.5"></div>
<div class="tag" style="margin-top:6px">Niveau du modèle d'IA</div>
<div class="models" id="models">
<button type="button" data-m="haiku" aria-pressed="false"><b>Économique</b><span>Haiku 4.5 · 1 $ / 5 $</span></button>
<button type="button" data-m="sonnet" aria-pressed="true"><b>Équilibré</b><span>Sonnet 5.5 · 2 $ / 10 $</span></button>
<button type="button" data-m="opus" aria-pressed="false"><b>Avancé</b><span>Opus 5.5 · 4 $ / 20 $</span></button>
</div>
<p class="note">Prix publics du fournisseur, en dollars par million de jetons (lecture / écriture).</p>
</div>
<div style="display:flex;flex-direction:column;gap:16px">
<div class="card dark"><div class="tag">Votre coût d'usage estimé</div>
<div class="big"><span id="r-cost">0,00 €</span> <small>/ mois</small></div>
<p>Fourchette selon la variation de vos usages : de <span id="r-cost2">0,00 €</span> à <span id="r-high">0,00 €</span>. Soit environ <span id="r-per">0,00 €</span> par demande.</p></div>
<div class="card"><div class="tag">Ce qui est inclus dans votre abonnement</div>
<p>L'usage courant est inclus, jusqu'à un seuil défini au devis. Au-delà, l'excédent est refacturé.</p>
<p id="r-seuil" style="font-weight:600;color:var(--teal)"></p></div>
<p class="note" id="r-note"></p>
</div></div>""", ))

b.append(S("contact","Pour démarrer","Pour démarrer","""
<h2>Une première conversation, puis un agent qui travaille pour vous.</h2>
<div class="grid g4 steps">
<div class="card"><div class="price">1</div><h3>Échange</h3><p>Vous nous décrivez les tâches qui vous prennent du temps.</p></div>
<div class="card"><div class="price">2</div><h3>Choix de la formule</h3><p>Agent standard, ou sur mesure avec un cadrage préalable.</p></div>
<div class="card"><div class="price">3</div><h3>Livraison</h3><p>Vous recevez l'agent adapté à votre outil et à votre métier.</p></div>
<div class="card"><div class="price">4</div><h3>Suivi</h3><p>Vous nous signalez ce qui doit évoluer, à 49 € de l'heure si besoin.</p></div>
</div>
<div class="grid g2">
<div class="card dark"><div class="tag">Un tarif horaire unique</div><div class="price">49 € <small>/ heure</small></div><p>Audit en visio, modifications, nouvelles fonctions, heures hors forfait : un seul tarif, annoncé avant chaque intervention.</p></div>
<div class="card accent"><div class="tag">Parlons de votre projet</div>
<h3>La Maison du CREL</h3>
<p><a href="%s">%s</a></p>
<p><a href="%s">%s</a> · appels et <a href="%s" target="_blank" rel="noopener">WhatsApp</a></p>
<p><a href="%s" target="_blank" rel="noopener">medy.site/offreco</a></p>
<div class="ctas" style="margin-top:8px"><a class="btn" href="%s">Nous écrire</a><a class="btn ghost" href="%s" target="_blank" rel="noopener">WhatsApp</a></div>
</div></div>
%s""" % (MAIL_HREF, EMAIL, TEL_HREF, TEL, WA, SITE, MAIL_HREF, WA, TVA), alt=True))

body="".join(b)+'<div class="footer">La Maison du CREL · <a href="%s">%s</a> · <a href="%s">%s</a> · Prix nets, TVA non applicable, article 293 B du CGI.</div>' % (MAIL_HREF, EMAIL, "https://medy.site", "medy.site")

JS = """
/* Calculateur : réglages à modifier ici */
var SEUIL = 0;    /* seuil d'usage inclus, en euros par mois ; 0 = "précisé dans le devis" */
var TAUX  = 0.87; /* conversion indicative de 1 $ en euros */
var PRIX = {haiku:[1,5], sonnet:[2,10], opus:[4,20]}; /* prix publics, $ par million de jetons (lecture, écriture) */
(function(){
  var model='sonnet';
  function $(id){return document.getElementById(id);}
  var eur=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
  var num=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2});
  var dec=new Intl.NumberFormat('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1});
  var int=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:0});
  function calc(){
    var dem=+$('c-dem').value, pin=+$('c-pin').value, eta=+$('c-eta').value, pout=+$('c-pout').value;
    $('o-dem').textContent=int.format(dem); $('o-pin').textContent=dec.format(pin);
    $('o-eta').textContent=int.format(eta); $('o-pout').textContent=dec.format(pout);
    var inTok=dem*eta*(pin*1000+1500), outTok=dem*pout*1000;
    var usd=inTok/1e6*PRIX[model][0]+outTok/1e6*PRIX[model][1];
    var cost=usd*TAUX;
    $('r-cost').textContent=eur.format(cost); $('r-cost2').textContent=eur.format(cost);
    $('r-high').textContent=eur.format(cost*1.5);
    $('r-per').textContent=eur.format(dem>0?cost/dem:0);
    $('r-seuil').textContent = SEUIL>0
      ? 'Seuil inclus : '+eur.format(SEUIL)+' par mois. '+(cost>SEUIL?'Votre estimation dépasse le seuil de '+eur.format(cost-SEUIL)+' : cet excédent est refacturé.':'Votre estimation reste dans le seuil inclus.')
      : 'Votre seuil est précisé dans votre devis.';
    $('r-note').textContent='Estimation indicative : '+num.format(inTok/1e6)+' M de jetons lus et '+num.format(outTok/1e6)+' M écrits par mois. Une page représente environ 1 000 jetons ; les consignes de l\\u2019agent, environ 1 500 jetons par étape. Prix publics du fournisseur au 29 septembre 2026, susceptibles d\\u2019évoluer ; conversion indicative de 1 $ pour '+TAUX.toFixed(2).replace('.',',')+' €.';
  }
  ['c-dem','c-pin','c-eta','c-pout'].forEach(function(id){$(id).addEventListener('input',calc);});
  [].forEach.call(document.querySelectorAll('#models button'),function(bt){
    bt.addEventListener('click',function(){
      model=bt.getAttribute('data-m');
      [].forEach.call(document.querySelectorAll('#models button'),function(x){x.setAttribute('aria-pressed',x===bt?'true':'false');});
      calc();
    });
  });
  calc();
})();
"""

html=page("La Maison du CREL · Nos offres d'automatisation par l'IA",
          "Socle, agent standard et agent sur mesure : des prix clairs, expliqués un par un.",
          "La Maison du CREL", body, JS)
open('/mnt/user-data/outputs/offreco-client.html','w',encoding='utf-8').write(html)
print(len(html))
