# -*- coding: utf-8 -*-
LIGHT = """--bg:#F4F0E8;--surface:#FFFFFF;--ink:#14202B;--muted:#4A5560;--line:#D9D2C3;--sand:#E8E2D4;
--teal:#0B5F57;--teal-soft:#E3F3F0;--on-teal:#FFFFFF;--rust:#A63A14;--rust-soft:#FBE3D8;--rust-ink:#7A2A0E;
--dark:#14202B;--on-dark:#D5DCE2;--on-dark-strong:#FFFFFF;--mint:#8FD3C6;--bar:#0B5F57;--bar-alt:#A63A14;--ring:#0B5F57;"""
DARK = """--bg:#0F171F;--surface:#18232E;--ink:#EDF0F3;--muted:#A9B4BF;--line:#2C3B49;--sand:#263341;
--teal:#6FC8BA;--teal-soft:#12332F;--on-teal:#0B1A18;--rust:#F0906A;--rust-soft:#3B2016;--rust-ink:#F6C9B4;
--dark:#0A1117;--on-dark:#C4CDD6;--on-dark-strong:#FFFFFF;--mint:#8FD3C6;--bar:#6FC8BA;--bar-alt:#F0906A;--ring:#6FC8BA;"""

CSS = """
:root{%LIGHT%}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){%DARK%}}
:root[data-theme="dark"]{%DARK%}
:root{box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}
html{scroll-padding-top:env(safe-area-inset-top,0px);scroll-behavior:smooth;scroll-snap-type:y proximity}
*,*::before,*::after{box-sizing:inherit}
body{margin:0;background:var(--bg);color:var(--ink);font-family:'Public Sans',system-ui,-apple-system,'Segoe UI',sans-serif;font-size:17px;line-height:1.55;-webkit-font-smoothing:antialiased}
h1,h2,h3{font-family:'Fraunces',Georgia,'Times New Roman',serif;font-weight:700;line-height:1.1;margin:0;letter-spacing:-0.01em}
h1{font-size:clamp(2.3rem,5.2vw,4rem)}
h2{font-size:clamp(1.8rem,3.6vw,2.7rem)}
h3{font-size:1.3rem;line-height:1.2}
p{margin:0}
a{color:var(--teal)}
.topbar{position:fixed;top:0;left:0;right:0;z-index:20;padding:calc(env(safe-area-inset-top,0px) + 10px) 20px 8px;display:flex;align-items:center;justify-content:space-between;gap:16px;background:color-mix(in srgb,var(--bg) 92%,transparent);backdrop-filter:blur(6px);border-bottom:1px solid var(--line);font-size:14px}
.topbar .brand{font-weight:600;letter-spacing:.04em}
.topbar .count{color:var(--muted);font-variant-numeric:tabular-nums}
.progress{position:absolute;left:0;bottom:-1px;height:3px;background:var(--teal);width:0}
.dots{position:fixed;right:18px;top:50%;transform:translateY(-50%);z-index:15;display:flex;flex-direction:column;gap:10px}
.dots a{display:block;width:12px;height:12px;border-radius:50%;border:2px solid var(--teal);background:transparent;padding:0}
.dots a[aria-current="true"]{background:var(--teal)}
@media (max-width:900px){.dots{display:none}}
.slide{min-height:100vh;min-height:100svh;scroll-snap-align:start;display:flex;align-items:center;padding:96px 24px 56px}
.slide.alt{background:color-mix(in srgb,var(--sand) 45%,var(--bg))}
.wrap{width:100%;max-width:1120px;margin:0 auto;display:flex;flex-direction:column;gap:28px}
.eyebrow{font-size:13px;font-weight:600;letter-spacing:.14em;text-transform:uppercase;color:var(--teal)}
.eyebrow.rust{color:var(--rust)}
.lead{font-size:clamp(1.05rem,1.7vw,1.3rem);color:var(--muted);max-width:60ch}
.grid{display:grid;gap:20px}
.g2{grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr))}
.g3{grid-template-columns:repeat(auto-fit,minmax(min(100%,260px),1fr))}
.g4{grid-template-columns:repeat(auto-fit,minmax(min(100%,220px),1fr))}
.card{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:24px;display:flex;flex-direction:column;gap:10px}
.card.accent{border-color:var(--teal);border-width:2px}
.card.dark{background:var(--dark);color:var(--on-dark);border-color:transparent}
.card.dark h3,.card.dark .price,.card.dark strong{color:var(--on-dark-strong)}
.card.dashed{border-style:dashed;border-color:var(--teal)}
.tag{font-size:13px;font-weight:600;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}
.card.dark .tag{color:var(--mint)}
.card.accent .tag{color:var(--teal)}
.price{font-family:'Fraunces',Georgia,serif;font-weight:700;font-size:clamp(2rem,3.4vw,2.7rem);line-height:1.05;color:var(--teal)}
.price small{font-family:'Public Sans',system-ui,sans-serif;font-size:1rem;font-weight:500;color:var(--muted)}
.card.dark .price{color:var(--mint)}
.card.dark .price small{color:var(--on-dark)}
.callout{border-radius:14px;padding:16px 20px;background:var(--teal-soft);color:var(--teal)}
.callout.rust{background:var(--rust-soft);color:var(--rust-ink)}
.callout.sand{background:var(--sand);color:var(--ink)}
.callout b{font-weight:600}
.note{font-size:14px;color:var(--muted)}
.list{display:flex;flex-direction:column;gap:10px;margin:0;padding:0;list-style:none}
.list li{position:relative;padding-left:22px}
.list li::before{content:"";position:absolute;left:0;top:.62em;width:9px;height:9px;border-radius:50%;background:var(--teal)}
.warn{border-top:3px solid var(--rust);padding-top:12px}
.good{border-top:3px solid var(--teal);padding-top:12px}
.neutral{border-top:3px solid var(--muted);padding-top:12px}
.barrow{display:grid;grid-template-columns:minmax(110px,230px) 1fr auto;gap:14px;align-items:center;padding:6px 0}
.barrow .lab{font-weight:600}
.bar{height:16px;background:var(--sand);border-radius:8px;overflow:hidden}
.bar i{display:block;height:100%;background:var(--bar);border-radius:8px}
.bar i.alt{background:var(--bar-alt)}
.barrow .val{font-variant-numeric:tabular-nums;text-align:right;min-width:88px}
@media (max-width:560px){.barrow{grid-template-columns:1fr auto}.barrow .bar{grid-column:1 / -1;order:3}}
.tblwrap{overflow-x:auto;border:1px solid var(--line);border-radius:16px;background:var(--surface)}
table{border-collapse:collapse;width:100%;min-width:560px}
th{font-size:13px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted);text-align:left;padding:14px 18px;border-bottom:2px solid var(--ink)}
td{padding:13px 18px;border-bottom:1px solid var(--line);font-variant-numeric:tabular-nums}
tr:last-child td{border-bottom:0}
td.pos{color:var(--teal);font-weight:600}
td.neg{color:var(--rust);font-weight:600}
.steps{counter-reset:s}
.step{position:relative;padding-top:14px;border-top:4px solid var(--teal)}
.step h3{font-size:1.1rem}
.split{display:flex;gap:6px;flex-wrap:nowrap}
.split div{border-radius:12px;padding:18px 20px;color:#fff;display:flex;flex-direction:column;gap:4px}
.split .a{background:#A63A14}.split .b{background:#0B5F57}.split .c{background:#4A5560}
.split .tag{color:rgba(255,255,255,.85)}
.split strong{font-family:'Fraunces',Georgia,serif;font-size:1.35rem;line-height:1.15}
@media (max-width:640px){.split{flex-direction:column}.split div{flex-basis:auto !important}}
.chips{display:flex;gap:6px}
.chips span{flex:1;background:var(--teal);color:var(--on-teal);border-radius:8px;text-align:center;padding:10px 0;font-weight:600;font-size:15px}
.btn{display:inline-flex;align-items:center;gap:8px;min-height:48px;padding:0 22px;border-radius:999px;border:2px solid var(--teal);background:var(--teal);color:var(--on-teal);font-weight:600;text-decoration:none;font-size:16px}
.btn.ghost{background:transparent;color:var(--teal)}
.btn:focus-visible,a:focus-visible,button:focus-visible,input:focus-visible{outline:3px solid var(--ring);outline-offset:2px}
.ctas{display:flex;gap:12px;flex-wrap:wrap}
.calc{display:grid;gap:24px;grid-template-columns:minmax(0,1.1fr) minmax(0,1fr)}
@media (max-width:900px){.calc{grid-template-columns:1fr}}
.field{display:flex;flex-direction:column;gap:2px}
.field .row{display:flex;justify-content:space-between;font-weight:600;font-size:15px;gap:12px}
.field .row output{color:var(--teal)}
input[type=range]{width:100%;accent-color:var(--teal);height:32px;margin:0}
input[type=number]{width:100%;height:48px;border:1px solid var(--line);border-radius:10px;padding:0 12px;font:inherit;background:var(--surface);color:var(--ink)}
.models{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.models button{font:inherit;text-align:left;padding:10px 12px;min-height:64px;border-radius:12px;border:2px solid var(--line);background:var(--surface);color:var(--ink);cursor:pointer}
.models button[aria-pressed="true"]{background:var(--teal);border-color:var(--teal);color:var(--on-teal)}
.models b{display:block;font-size:14px}.models span{font-size:12.5px;opacity:.9}
.big{font-family:'Fraunces',Georgia,serif;font-weight:700;font-size:clamp(2.4rem,4.4vw,3.4rem);line-height:1;color:var(--on-dark-strong)}
.big small{font-family:'Public Sans',system-ui,sans-serif;font-size:1rem;font-weight:500;color:var(--on-dark)}
.footer{padding:24px 24px 48px;text-align:center;color:var(--muted);font-size:14px}
@media print{.topbar,.dots{display:none}.slide{min-height:auto;page-break-after:always}}
""".replace("%LIGHT%", LIGHT).replace("%DARK%", DARK)

HEAD = """<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>%TITLE%</title>
<meta name="description" content="%DESC%">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Public+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>%CSS%</style>
</head>
<body>
"""

NAVJS = """
(function(){
  var slides=[].slice.call(document.querySelectorAll('.slide'));
  var dots=document.getElementById('dots');
  var count=document.getElementById('count');
  var prog=document.getElementById('progress');
  slides.forEach(function(s,i){
    var a=document.createElement('a');
    a.href='#'+s.id; a.setAttribute('aria-label',(i+1)+'. '+(s.getAttribute('data-title')||s.id)); a.title=s.getAttribute('data-title')||'';
    dots.appendChild(a);
  });
  var links=[].slice.call(dots.children);
  function cur(){
    var y=window.scrollY+window.innerHeight*0.4, idx=0;
    slides.forEach(function(s,i){ if(s.offsetTop<=y) idx=i; });
    return idx;
  }
  function update(){
    var i=cur();
    links.forEach(function(l,k){ if(k===i) l.setAttribute('aria-current','true'); else l.removeAttribute('aria-current'); });
    count.textContent=(i+1)+' / '+slides.length;
    var h=document.documentElement.scrollHeight-window.innerHeight;
    prog.style.width=(h>0?Math.min(100,window.scrollY/h*100):0)+'%';
  }
  window.addEventListener('scroll',update,{passive:true});
  window.addEventListener('resize',update);
  update();
  document.addEventListener('keydown',function(e){
    var t=e.target&&e.target.tagName; if(t==='INPUT'||t==='TEXTAREA'||t==='BUTTON'||t==='A') return;
    var i=cur();
    if(e.key==='ArrowDown'||e.key==='PageDown'||e.key==='ArrowRight'){ if(i<slides.length-1){e.preventDefault();slides[i+1].scrollIntoView({behavior:'smooth'});} }
    if(e.key==='ArrowUp'||e.key==='PageUp'||e.key==='ArrowLeft'){ if(i>0){e.preventDefault();slides[i-1].scrollIntoView({behavior:'smooth'});} }
  });
})();
"""

def page(title, desc, brand, body, extra_js=""):
    head = HEAD.replace("%TITLE%", title).replace("%DESC%", desc).replace("%CSS%", CSS)
    top = ('<header class="topbar"><span class="brand">%s</span><span class="count" id="count">1 / 1</span>'
           '<div class="progress" id="progress"></div></header>\n<nav class="dots" id="dots" aria-label="Sections"></nav>\n<main>\n') % brand
    return head + top + body + "\n</main>\n<script>" + NAVJS + extra_js + "</script>\n</body>\n</html>\n"

def S(id, title, eyebrow, inner, alt=False, rust=False):
    cls = "slide alt" if alt else "slide"
    eb = '<div class="eyebrow%s">%s</div>' % (" rust" if rust else "", eyebrow)
    return '<section class="%s" id="%s" data-title="%s"><div class="wrap">%s\n%s</div></section>\n' % (cls, id, title, eb, inner)
