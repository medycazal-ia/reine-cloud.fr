# -*- coding: utf-8 -*-
import sys
sys.path.insert(0,'/home/claude/gen')
from base import page, S

b=[]
def bar(lab,pct,val,alt=False):
    return '<div class="barrow"><span class="lab">%s</span><div class="bar"><i%s style="width:%s%%"></i></div><span class="val">%s</span></div>' % (lab, ' class="alt"' if alt else '', pct, val)

b.append(S("constat","Constat","Document interne · ne pas partager avec les clients","""
<h1>Revendre de l'hébergement et des agents IA : la demande existe, la marge est ailleurs.</h1>
<p class="lead">Où en est le marché, qui sont les concurrents, quelles chances de réussir. Réponse courte : ne vendez pas de l'hébergement seul.</p>
<div class="grid g3">
<div class="card"><div class="tag" style="color:var(--rust)">Hébergement seul</div><h3>Marge faible, prix tirés vers le bas</h3><p>Un compte cPanel revient à environ 2 € HT chez LWS (environ 2,40 € TTC pour vous, non assujetti), mais les concurrents s'affichent de 1,49 à 8 € au public.</p></div>
<div class="card"><div class="tag">Agents IA</div><h3>Demande forte, offre déjà dense</h3><p>Agences, plateformes no-code et freelances se disputent les mêmes PME. Se différencier devient obligatoire.</p></div>
<div class="card dark"><div class="tag">Les deux combinés</div><h3>La piste la plus crédible</h3><p>Un abonnement mensuel : agent + site + hébergement + maintenance, pour une niche métier précise.</p></div>
</div>
<p class="note">Sources : lws.fr (offres Reseller), comparatifs d'hébergeurs français 2026, benchmarks IA et automatisation 2026. Les scores de la planche « Verdict » sont des estimations qualitatives.</p>"""))

b.append(S("vigilance","Point de vigilance","Point de vigilance","""
<h2>lwspanel.fr n'est pas le programme revendeur de LWS.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Ce que j'ai trouvé</div><ul class="list">
<li>lwspanel.fr affiche une page d'accueil de domaine « créé avec LWS » : c'est un nom de domaine enregistré, pas une offre.</li>
<li>LWS Panel désigne l'espace client de LWS, accessible sur panel.lws.fr.</li>
<li>L'offre revendeur s'appelle LWS Reseller (S, M, L, XL) sur lws.fr, avec cPanel, WHM et marque blanche.</li></ul></div>
<div class="card"><div class="tag" style="color:var(--rust)">À vérifier avant de payer</div><ul class="list">
<li>lwspanel.host se présente comme un hébergeur « Lwspanel ». Aucun lien avec LWS n'a pu être confirmé : ne pas confondre.</li>
<li>Commandez uniquement depuis lws.fr ou panel.lws.fr, et contrôlez l'adresse avant tout paiement.</li>
<li>LWS propose aussi un programme Agence web (remises à vie selon un seuil) et un Cloud cPanel en marque blanche.</li></ul></div>
</div>
<div class="tag">Comment fonctionne la revente</div>
<div class="grid g3">
<div class="card dark"><h3>LWS</h3><p>Serveur, cPanel, WHM, sauvegardes, support 7j/7.</p></div>
<div class="card accent"><h3>Vous</h3><p>Votre marque, vos packs, votre facturation, votre support.</p></div>
<div class="card"><h3>Vos clients</h3><p>Un compte cPanel chacun, autonomes sur leurs sites et e-mails.</p></div>
</div>""", alt=True, rust=True))

b.append(S("economie","Économie de la revente","L'hébergement revendeur, en chiffres","""
<h2>Un ticket d'entrée bas, mais une marge plafonnée.</h2>
<div class="card">
"""+bar("Reseller S",25,"19,99 € HT · 10 comptes · 60 Go")
+bar("Reseller M",50,"39,99 € HT · 20 comptes · 120 Go")
+bar("Reseller L",75,"59,99 € HT · 30 comptes · 160 Go")
+bar("Reseller XL",100,"99,99 € HT · 40 comptes · 200 Go")+"""
<p class="note">La barre représente le nombre de comptes cPanel. Coût par compte : environ 2 € HT (2,50 € en XL), soit environ 2,40 € TTC pour vous, qui ne récupérez pas la TVA. Reseller M est indiqué comme le plus vendu ; le Reseller S revient à 23,99 € TTC par mois.</p></div>
<div class="grid g3">
<div class="warn"><strong>Coûts cachés.</strong> La licence WHMCS (facturation) est en option, l'infogérance démarre à 9,99 € HT l'acte.</div>
<div class="warn"><strong>Matériel affiché.</strong> Processeurs Xeon E5 v4, 180 processus, 100 IOPS : suffisant pour des sites vitrines, limité au-delà.</div>
<div class="warn"><strong>Engagement.</strong> Reconduction tacite, satisfait ou remboursé 30 jours : de quoi tester sans gros risque.</div>
</div>"""))

b.append(S("concurrence","Concurrence hébergement","Concurrence : hébergement","""
<h2>Vous ne gagnerez pas sur le prix.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Prix mensuel d'entrée pour un client (€)</div>
"""+bar("Hostinger (promo)",7.5,"1,49")+bar("OVHcloud",18,"3,59")+bar("o2switch",40,"7,99")
+bar("Votre socle",100,"19,99")+bar("Votre coût par compte",12,"2,40",True)+"""
<p class="note">Prix publics relevés dans des comparatifs de 2026. Les tarifs promotionnels sont valables sur engagement long ; le renouvellement coûte souvent 3 à 5 fois plus cher.</p></div>
<div style="display:flex;flex-direction:column;gap:16px">
<div class="card"><h3>Des géants installés</h3><p>OVHcloud revendique plus de 1,5 million de clients professionnels ; o2switch reste la référence des PME avec son offre unique.</p></div>
<div class="card"><h3>Le site généré par IA</h3><p>Hostinger et LWS offrent déjà un créateur de site IA : l'hébergement devient une commodité incluse.</p></div>
<div class="card accent"><h3>Où un petit revendeur gagne</h3><p>Service de proximité, réactivité, et un forfait qui inclut site, e-mails, maintenance et automatisations.</p></div>
</div></div>""", alt=True, rust=True))

b.append(S("agents","Marché des agents IA","Marché des agents IA","""
<h2>Une demande qui décolle, une offre qui se densifie.</h2>
<div class="grid g3">
<div class="card"><div class="price">13,8 Md$</div><p>Marché mondial du RPA en 2026 (Markets and Markets, cité par un benchmark 2026).</p></div>
<div class="card"><div class="price">19,6 Md$</div><p>Projection pour les outils d'automatisation no-code et IA (même source).</p></div>
<div class="card"><div class="price">75 %</div><p>Des entreprises de plus de 20 salariés utiliseraient des agents IA d'ici 2027 (McKinsey, cité).</p></div>
</div>
<div class="grid g2">
<div style="display:flex;flex-direction:column;gap:10px"><div class="tag">Qui vous concurrence</div>
<div class="card dark"><p><strong>Plateformes d'agents</strong> : Le Chat de Mistral, Dust, H et d'autres, visant PME et grands comptes.</p></div>
<div class="card"><p><strong>Agences d'automatisation</strong> : des dizaines en France, souvent spécialistes de n8n et des workflows agentiques.</p></div>
<div class="card"><p><strong>Freelances et marketplaces</strong> : honoraires souvent plus bas, sans engagement long.</p></div>
<div class="card"><p><strong>Agences en marque blanche</strong> : segment en forte croissance selon un blog sectoriel (estimation, à prendre avec recul).</p></div></div>
<div style="display:flex;flex-direction:column;gap:10px"><div class="tag">Vos deux produits</div>
<div class="card"><h3>Sur mesure</h3><p>Prix élevé et vraie différenciation, mais cycle de vente long et charge de maintenance.</p></div>
<div class="card"><h3>Agent standard</h3><p>Facile à répéter, mais copiable en quelques heures avec des outils no-code : la marge s'érode vite.</p></div>
<div class="callout rust"><b>Une agence qui vend « de l'IA » en général tombe dans la guerre des devis.</b></div></div>
</div>"""))

b.append(S("verdict","Verdict","Verdict","""
<h2>Réussir, oui, en vendant un abonnement plutôt qu'un serveur.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Chances de réussite (estimation sur 5)</div>
"""+bar("Hébergement revendeur seul",30,"1,5",True)+bar("Agents livrés tels quels",40,"2",True)+bar("Agents sur mesure, une niche",70,"3,5")+bar("Offre combinée en abonnement",80,"4")+"""
<p class="note">Jugement qualitatif fondé sur les marges, la concurrence et la difficulté de différenciation relevées ici. Ce ne sont pas des mesures.</p></div>
<div class="card dark"><div class="tag">Par où commencer</div><ul class="list">
<li><strong>1. Tester.</strong> Reseller S avec le satisfait ou remboursé de 30 jours.</li>
<li><strong>2. Choisir une niche.</strong> Un métier précis, avec des tâches répétitives que vous connaissez (exemple : les opticiens et le tiers payant).</li>
<li><strong>3. Facturer au mois.</strong> Agent + site + hébergement + maintenance dans un seul forfait.</li>
<li><strong>4. Valider par 3 pilotes payants</strong> avant d'investir davantage.</li></ul></div>
</div>
<div class="grid g2">
<div class="warn"><strong>Technique.</strong> Un hébergement cPanel n'est pas fait pour faire tourner des agents en continu : prévoir un VPS ou un orchestrateur (n8n, Make).</div>
<div class="warn"><strong>Juridique.</strong> Contrats clairs sur RGPD, AI Act et réversibilité, que les clients PME commencent à exiger. Consultez un juriste pour les détails.</div>
</div>""", alt=True))

b.append(S("offre","Votre offre","Approfondissement 1 · Votre offre","""
<h2>Trois niveaux d'abonnement, et des options à la carte.</h2>
<div class="grid g3">
<div class="card"><div class="tag">Socle</div><h3>Site + e-mails + hébergement</h3><p>Sauvegardes, mises à jour, support, et 2 révisions par an de changements rapides et simples avec le client.</p><div class="price">19,99 € <small>/ mois</small></div></div>
<div class="card accent"><div class="tag">Agent standard</div><h3>Un agent standard en plus</h3><p>2 problématiques proches (même outil), adaptées sans frais. Audit en visio en option : 1 ou 2 h à 49 €/h. Avec le socle : 118,99 €/mois. Remise dès 3 agents.</p><div class="price">99 € <small>/ mois</small></div>
<div class="callout" style="font-size:14px">Soit environ 4 heures de travail d'un salarié. Si l'agent vous en fait gagner davantage, il est rentabilisé.</div></div>
<div class="card dark"><div class="tag">Sur mesure</div><h3>Agents adaptés au métier</h3><p>Mise en place unique, puis abonnement de suivi.</p><div class="price">dès 299 € <small>/ mois</small></div><strong>+ mise en place dès 1 500 €</strong></div>
</div>
<div class="card dashed"><h3>Options à la carte</h3><p>Facturées selon la demande et la difficulté : agent supplémentaire, connexion à un logiciel métier, cas particulier. Tarif horaire : 49 € de l'heure, chiffré sur devis selon la difficulté.</p></div>
<div class="grid g3">
<div class="warn"><strong>Le socle à 19,99 € reste au-dessus du marché.</strong> Les hébergeurs seuls s'affichent de 1,49 à 8 € par mois : justifiez l'écart par le service (site, e-mails, réactivité). Il ne dégage qu'environ 18 € par client.</div>
<div class="warn"><strong>L'agent à 99 € n'inclut aucune heure de suivi.</strong> L'adaptation de 2 problématiques proches (même outil) est gratuite si le client les envoie ; le reste est facturé 49 € de l'heure. API et outils restent à votre charge.</div>
<div class="warn"><strong>Cadré.</strong> Un changement « rapide et simple » = environ 1 heure par révision, 2 par an. Prix nets, sans TVA. À préciser : durée d'engagement, et effet du dépassement du seuil de franchise de TVA.</div>
</div>"""))

b.append(S("scenario","Scénario chiffré","Approfondissement 1 · Rentabilité","""
<h2>Avec vos prix, la marge vient surtout des agents.</h2>
<div class="calc">
<div class="card"><div class="tag">Scénario illustratif : 8 clients (hypothèse)</div>
"""+bar("4 clients socle × 19,99 €",22,"80 €")+bar("3 clients socle + agent × 118,99 €",100,"357 €")+bar("1 client sur mesure × dès 299 €",84,"299 €")+bar("Serveur Reseller S (TTC)",8,"− 23,99 €",True)+"""
<p class="note">Huit comptes cPanel tiennent dans les 10 du Reseller S. Le sur mesure est compté à son minimum. Vos prix sont nets (sans TVA), donc le serveur est compté TTC. Le socle est compté à 19,99 €, l'agent ajouté à 99 €.</p></div>
<div class="card dark"><div class="tag">Résultat du scénario</div><div class="big">≈ 712 € <small>/ mois</small></div>
<p>Récurrent, avant outils, API des modèles et votre temps. Soit environ 8 500 € par an, plus 1 500 € de mise en place une seule fois.</p>
<p><strong>Point de vigilance du serveur : deux clients socle pour le couvrir.</strong></p></div>
</div>
<div class="grid g3">
<div class="warn"><strong>Votre vrai coût, c'est le temps.</strong> Le socle laisse environ 210 € par an et par client après le serveur : à 50 € de l'heure (exemple), environ 4 heures. Vos deux révisions d'une heure en consomment la moitié. L'agent à 99 € n'inclut aucune heure : tout suivi est facturé 49 € de l'heure.</div>
<div class="warn"><strong>Coûts à ajouter.</strong> Outils d'automatisation, API des modèles, licence WHMCS si vous facturez avec, et un VPS si les agents tournent en continu : [VOS COÛTS], à compter TTC.</div>
<div class="warn"><strong>Le scénario reste une hypothèse.</strong> Huit clients supposent des ventes réussies : validez d'abord avec trois pilotes payants.</div>
</div>""", alt=True))

b.append(S("surmesure","Offre sur mesure","Offre sur mesure · détail","""
<h2>Des prix « à partir de », un cadre clair, un suivi plafonné.</h2>
<div class="grid g3">
<div class="card dark"><div class="tag">Mise en place</div><div class="price">à partir de 1 500 €</div><p>Trois niveaux : faible, moyenne, forte, selon les outils connectés, les données sensibles et le volume. Prix exact sur devis, moins 50 % du cadrage si celui-ci a été acheté (99,50 € pour 3 h).</p></div>
<div class="card dark"><div class="tag">Abonnement</div><div class="price">à partir de 299 € <small>/ mois</small></div><p>Suivi, rapport mensuel et forfait de 2 h de révisions. Le prix monte avec le nombre d'agents et leur usage.</p></div>
<div class="card dashed"><div class="tag">Cadrage préalable</div><div class="price">199 €</div><p>Séance payante avant le devis, limitée à 3 h. Au-delà : 49 € de l'heure en plus. Si le client signe, 50 % du cadrage, heures en plus comprises, sont déduits de la mise en place.</p></div>
</div>
<div class="grid g4 steps">
<div class="step"><h3>1 · Cadrage</h3><p class="note">Besoin, outils, données, critères de réussite.</p></div>
<div class="step"><h3>2 · Construction</h3><p class="note">Agent, connexions, tests, documentation.</p></div>
<div class="step"><h3>3 · Recette</h3><p class="note">Validation signée de ce qui est « livré ».</p></div>
<div class="step"><h3>4 · Suivi mensuel</h3><p class="note">Supervision, corrections, rapport d'activité.</p></div>
</div>
<div class="grid g2">
<div class="card accent"><div class="tag">Inclus dans l'abonnement</div><ul class="list"><li>Supervision et corrections de l'agent.</li><li>Forfait de 2 h de révisions par mois (3 interventions maximum), non cumulables.</li><li>Rapport mensuel d'activité.</li></ul></div>
<div class="card" style="border-color:var(--rust)"><div class="tag" style="color:var(--rust)">Facturé en plus (à la carte)</div><ul class="list"><li>Heures au-delà du forfait de 2 h, à 49 € de l'heure.</li><li>Coûts d'API et d'outils au-delà de [SEUIL] (voir le calculateur).</li><li>Nouvelles fonctions et options, à 49 € de l'heure selon la demande et la difficulté.</li></ul></div>
</div>
<div class="callout sand"><b>Contrat à prévoir :</b> prix nets (sans TVA), engagement de 24 mois, renouvellement tacite pour 24 mois sauf préavis de 6 mois, indemnité de sortie à 75 % puis 50 %, recette signée, RGPD et réversibilité. À faire relire par un juriste.</div>"""))

b.append(S("engagement","Engagement","Sur mesure · engagement","""
<h2>24 mois d'engagement, avec une sortie à 75 % puis 50 % du reste à payer.</h2>
<div class="split">
<div class="a" style="flex:1 1 25%"><span class="tag">Sortie avant 6 mois</span><strong>75 % du reste à payer</strong></div>
<div class="b" style="flex:1 1 75%"><span class="tag">Sortie à partir de 6 mois</span><strong>50 % du reste à payer</strong></div>
</div>
<div class="callout" style="background:var(--dark);color:var(--on-dark)"><b style="color:#fff">Contrat complet, au minimum :</b> 24 × 299 € = 7 176 €, plus 199 € de cadrage de 3 h, plus 1 400,50 € de mise en place (1 500 € moins 50 % du cadrage), soit 8 775,50 €.</div>
<div class="grid g2">
<div class="card"><p><strong style="color:var(--rust)">Exemple · départ après 3 mois.</strong> Reste 21 × 299 € = 6 279 €. Le client paie 75 %, soit environ <strong>4 709 €</strong>.</p></div>
<div class="card"><p><strong style="color:var(--teal)">Exemple · départ après 12 mois.</strong> Reste 12 × 299 € = 3 588 €. Le client paie 50 %, soit <strong>1 794 €</strong>.</p></div>
</div>
<p class="note">Calculs au prix minimum, sur les mensualités restantes seulement, hors mise en place et options. Le montant réel dépend de l'abonnement signé.</p>
<div class="grid g3">
<div class="good"><strong>À écrire dans le contrat.</strong> Base de calcul, point de départ des 6 mois, forme de la résiliation, et sortie sans indemnité si vous manquez gravement à vos engagements.</div>
<div class="warn"><strong>Solidité juridique.</strong> Cette indemnité relève d'une clause pénale : entre professionnels, un juge peut la réduire si elle paraît manifestement excessive. Faites relire par un juriste.</div>
<div class="neutral"><strong>Cohérence.</strong> Avec ces paliers, l'engagement n'est plus « ferme » au sens strict : le client peut partir en payant. Dites-le clairement dans le contrat.</div>
</div>""", alt=True))

b.append(S("heures","Heures et renouvellement","Sur mesure · heures et renouvellement","""
<h2>Deux heures par mois, non cumulables, puis un contrat qui se renouvelle sauf préavis.</h2>
<div class="grid g2">
<div class="card"><div class="tag">Heures de révision</div>
<p>2 h par mois au maximum pour le sur mesure. Les heures non utilisées ne se cumulent pas : elles sont perdues à la fin du mois.</p>
<div class="chips"><span>2 h</span><span>2 h</span><span>2 h</span><span>2 h</span><span>2 h</span><span>2 h</span></div>
<p class="note">Chaque mois repart à 2 h · Mois 1 à 6</p>
<div class="callout rust"><b>Exemple :</b> 0,5 h utilisée en mars, 1,5 h perdue. Avril repart à 2 h.</div></div>
<div class="card"><div class="tag">Renouvellement tacite</div>
<p>Le contrat se renouvelle à l'échéance, sauf préavis notifié 6 mois avant la fin, donc avant le mois 18.</p>
<div class="split"><div class="b" style="flex:18 1 0;padding:12px"><strong style="font-size:1rem">Préavis possible</strong></div><div class="a" style="flex:6 1 0;padding:12px"><strong style="font-size:1rem">Trop tard</strong></div></div>
<p class="note">Mois 0 · Mois 18 · Mois 24</p>
<div class="callout sand"><b>Durée du renouvellement :</b> 24 mois, comme la période initiale.</div></div>
</div>
<div class="grid g3">
<div class="good"><strong>Limite fixée.</strong> 3 interventions par mois au maximum, soit environ 40 min chacune en moyenne. Ces 2 h ne concernent que le sur mesure : l'agent standard est facturé à l'heure.</div>
<div class="warn"><strong>Charge de travail.</strong> Au maximum, 2 h valent 98 € de votre temps à 49 € de l'heure, pour 299 € facturés : il reste environ 201 € pour la supervision, le rapport mensuel et l'API.</div>
<div class="neutral"><strong>Rappel avant échéance.</strong> Envoyez un rappel écrit avant la date limite de préavis. Avec des particuliers, la loi impose des informations précises avant la reconduction : faites relire par un juriste.</div>
</div>"""))

b.append(S("remises","Remises agents standard","Agent standard · remises","""
<h2>Plus le client prend d'agents, plus il a de remise, jusqu'à 40 %.</h2>
<div class="tblwrap"><table>
<thead><tr><th>Agents</th><th>Remise</th><th>Prix mensuel</th><th>Par agent</th><th>Marge par agent après API (exemple)</th></tr></thead>
<tbody>
<tr><td><strong>1 agent</strong></td><td>0 %</td><td>99,00 €</td><td>99,00 €</td><td class="pos">75,60 €</td></tr>
<tr><td><strong>2 agents</strong></td><td>0 %</td><td>198,00 €</td><td>99,00 €</td><td class="pos">75,60 €</td></tr>
<tr><td><strong>3 agents</strong></td><td class="pos">20 %</td><td>237,60 €</td><td>79,20 €</td><td class="pos">55,80 €</td></tr>
<tr><td><strong>4 agents</strong></td><td class="pos">30 %</td><td>277,20 €</td><td>69,30 €</td><td class="pos">45,90 €</td></tr>
<tr><td><strong>5 agents</strong></td><td class="pos">40 %</td><td>297,00 €</td><td>59,40 €</td><td class="neg">36,00 €</td></tr>
<tr><td><strong>6 agents et plus</strong></td><td colspan="4" class="pos">Sur devis et négociation</td></tr>
</tbody></table></div>
<p class="note">Prix de base : 99 € par agent et par mois, net sans TVA. Un agent traite 2 problématiques proches, sur le même outil ; un autre outil ou une 3e problématique, c'est un agent de plus. Marge d'exemple : coût d'API de 23,40 € par agent, valeur par défaut fictive : remplacez-la par votre coût réel avec le calculateur.</p>
<div class="grid g3">
<div class="good"><strong>Règle appliquée.</strong> 20 % dès 3 agents, puis 10 % de plus par agent : 30 % à 4, 40 % à 5. La remise atteint 40 % à 5 agents. À partir du 6e agent, le prix est sur devis et négociation. Elle porte sur le total des agents standard.</div>
<div class="warn"><strong>Marge qui fond.</strong> À 5 agents, un agent rapporte 59,40 €, dont 36 € de marge après l'API d'exemple : une seule heure non payée à 49 € l'efface.</div>
<div class="neutral"><strong>Tranché.</strong> La remise suit les agents actifs : si le client en résilie, le taux baisse selon le nombre d'agents restants. Elle vaut aussi pour les agents ajoutés plus tard.</div>
</div>""", alt=True))

b.append(S("calculateur","Calculateur d'API","Calculateur · coûts d'API","""
<h2>Combien coûte un agent par mois, face à vos prix de vente ?</h2>
<div class="calc">
<div class="card">
<div class="field"><div class="row"><label for="i-dem">Demandes traitées par mois</label><output id="io-dem"></output></div><input id="i-dem" type="range" min="0" max="3000" step="10" value="200"></div>
<div class="field"><div class="row"><label for="i-pin">Pages lues par demande</label><output id="io-pin"></output></div><input id="i-pin" type="range" min="0" max="20" step="0.5" value="2"></div>
<div class="field"><div class="row"><label for="i-eta">Étapes par demande</label><output id="io-eta"></output></div><input id="i-eta" type="range" min="1" max="8" step="1" value="3"></div>
<div class="field"><div class="row"><label for="i-pout">Pages écrites par demande</label><output id="io-pout"></output></div><input id="i-pout" type="range" min="0" max="5" step="0.5" value="0.5"></div>
<div class="field"><div class="row"><label for="i-marge">Marge de sécurité (erreurs, relances, pics)</label><output id="io-marge"></output></div><input id="i-marge" type="range" min="1" max="3" step="0.1" value="2"></div>
<div class="grid g2"><div class="field"><label for="i-taux" class="note">Taux 1 $ en €</label><input id="i-taux" type="number" min="0.5" max="1.5" step="0.01" value="0.87"></div>
<div class="field"><label for="i-autres" class="note">Autres coûts (€ / mois)</label><input id="i-autres" type="number" min="0" step="1" value="0"></div></div>
<div class="models" id="imodels">
<button type="button" data-m="haiku" aria-pressed="false"><b>Haiku 4.5</b><span>1 $ / 5 $</span></button>
<button type="button" data-m="sonnet" aria-pressed="true"><b>Sonnet 5.5</b><span>2 $ / 10 $</span></button>
<button type="button" data-m="opus" aria-pressed="false"><b>Opus 5.5</b><span>4 $ / 20 $</span></button>
</div>
<p class="note">Prix publics du fournisseur au 29 septembre 2026 (page officielle de tarifs), en dollars par million de jetons. Une page ≈ 1 000 jetons, consignes ≈ 1 500 jetons par étape : estimations.</p>
</div>
<div style="display:flex;flex-direction:column;gap:16px">
<div class="card dark"><div class="tag">Coût mensuel total par client (avec marge de sécurité)</div>
<div class="big"><span id="ir-total">0,00 €</span> <small>/ mois</small></div>
<p id="ir-detail"></p></div>
<div class="card">
<div class="barrow"><span class="lab">Part des 99 € de l'agent standard</span><div class="bar"><i id="ib-99" style="width:0%"></i></div><span class="val" id="ip-99"></span></div>
<div class="barrow"><span class="lab">Part des 299 € du sur mesure (minimum)</span><div class="bar"><i id="ib-299" style="width:0%"></i></div><span class="val" id="ip-299"></span></div>
<div style="display:flex;justify-content:space-between;gap:12px;border-top:1px solid var(--line);padding-top:10px"><span>Reste sur l'agent standard, avant votre temps</span><strong id="ir-reste"></strong></div>
<div style="display:flex;justify-content:space-between;gap:12px"><span>Seuil d'API à proposer au client (arrondi)</span><strong id="ir-seuil" style="color:var(--teal)"></strong></div></div>
<div class="callout rust" id="ir-alerte" hidden><b>Attention :</b> le coût dépasse le prix de l'agent standard. Réduisez les étapes ou les tokens, ou prévoyez une refacturation.</div>
<p class="note">Comptez les coûts TTC, sans TVA récupérable. Formule : (jetons × prix ÷ 1 000 000) × taux × marge de sécurité + autres coûts.</p>
</div></div>""", ))

b.append(S("afaire","À faire avant de lancer","Avant de lancer","""
<h2>Six vérifications avant d'envoyer la première offre.</h2>
<div class="grid g3">
<div class="card"><div class="tag">1 · Juriste</div><p>Faire relire l'engagement de 24 mois, l'indemnité de sortie à 75 % puis 50 % et la reconduction tacite avec préavis de 6 mois.</p></div>
<div class="card"><div class="tag">2 · TVA</div><p>Vérifier auprès de l'administration ou d'un comptable le seuil de la franchise en base, et l'effet d'un dépassement sur vos prix.</p></div>
<div class="card"><div class="tag">3 · Coûts d'API réels</div><p>Faire tourner un agent une semaine en test, relever la consommation et remplacer les valeurs d'exemple du calculateur.</p></div>
<div class="card"><div class="tag">4 · Seuil d'usage</div><p>Fixer le seuil inclus dans les offres et le prix de l'excédent refacturé.</p></div>
<div class="card"><div class="tag">5 · Pilotes payants</div><p>Valider l'offre avec trois clients payants avant d'investir davantage.</p></div>
<div class="card"><div class="tag">6 · Niche</div><p>Choisir un métier précis et préparer une démonstration adaptée.</p></div>
</div>
<div class="callout sand"><b>Page client :</b> la présentation destinée aux clients est un document séparé, sans vos coûts ni vos marges.</div>""", alt=True))

body="".join(b)+'<div class="footer">Document interne · La Maison du CREL · à ne pas partager avec les clients.</div>'

JS = """
(function(){
  var model='sonnet';
  var PRIX={haiku:[1,5],sonnet:[2,10],opus:[4,20]};
  function $(id){return document.getElementById(id);}
  var eur=new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR'});
  var num=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2});
  var dec=new Intl.NumberFormat('fr-FR',{minimumFractionDigits:1,maximumFractionDigits:1});
  var int=new Intl.NumberFormat('fr-FR',{maximumFractionDigits:0});
  function calc(){
    var dem=+$('i-dem').value,pin=+$('i-pin').value,eta=+$('i-eta').value,pout=+$('i-pout').value,marge=+$('i-marge').value;
    var taux=parseFloat($('i-taux').value)||0, autres=parseFloat($('i-autres').value)||0;
    $('io-dem').textContent=int.format(dem);$('io-pin').textContent=dec.format(pin);$('io-eta').textContent=int.format(eta);
    $('io-pout').textContent=dec.format(pout);$('io-marge').textContent='× '+dec.format(marge);
    var inTok=dem*eta*(pin*1000+1500),outTok=dem*pout*1000;
    var brut=(inTok/1e6*PRIX[model][0]+outTok/1e6*PRIX[model][1])*taux;
    var avec=brut*marge, total=avec+autres;
    $('ir-total').textContent=eur.format(total);
    $('ir-detail').textContent='Lecture : '+num.format(inTok/1e6)+' M de jetons. Écriture : '+num.format(outTok/1e6)+' M. API brute : '+eur.format(brut)+'. Avec marge de sécurité : '+eur.format(avec)+'. Autres coûts : '+eur.format(autres)+'.';
    var p99=total/99*100,p299=total/299*100;
    $('ib-99').style.width=Math.min(100,p99)+'%';$('ib-299').style.width=Math.min(100,p299)+'%';
    $('ib-99').className=p99>50?'alt':'';$('ib-299').className=p299>50?'alt':'';
    $('ip-99').textContent=int.format(p99)+' %';$('ip-299').textContent=int.format(p299)+' %';
    var reste=99-total;
    $('ir-reste').textContent=eur.format(reste);$('ir-reste').style.color=reste<0?'var(--rust)':'var(--teal)';
    $('ir-seuil').textContent=eur.format(Math.ceil(total/5)*5);
    $('ir-alerte').hidden=!(total>99);
  }
  ['i-dem','i-pin','i-eta','i-pout','i-marge','i-taux','i-autres'].forEach(function(id){$(id).addEventListener('input',calc);});
  [].forEach.call(document.querySelectorAll('#imodels button'),function(bt){
    bt.addEventListener('click',function(){
      model=bt.getAttribute('data-m');
      [].forEach.call(document.querySelectorAll('#imodels button'),function(x){x.setAttribute('aria-pressed',x===bt?'true':'false');});
      calc();
    });
  });
  calc();
})();
"""
html=page("Revendeur d'hébergement et d'agents IA · Présentation interne",
          "État des lieux, offres, chiffres et calculs : document interne.",
          "Présentation interne", body, JS)
open('/mnt/user-data/outputs/presentation-interne.html','w',encoding='utf-8').write(html)
print(len(html))
