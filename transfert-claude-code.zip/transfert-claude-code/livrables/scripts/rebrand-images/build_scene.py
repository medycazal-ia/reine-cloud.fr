import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
SRC='/home/claude/rc/reine_cloud_full_scene.png'
OUT='/home/claude/rc_out/reine_cloud_full_scene.png'
F='/home/claude/fonts/'
A=672.0          # axe du reflet
BASE=610         # ligne de base du texte
SIZE=120
NEW_BOLD='reine'; NEW_LIGHT='-cloud.fr'
C_DARK=(73,30,101); C_LIGHT=(107,56,120)

img=np.array(Image.open(SRC).convert('RGB'))
S=img.astype(float)
R,G,B=S[...,0],S[...,1],S[...,2]
strong=((B-G>18)&(R-G>8))
H,W=strong.shape
# 1) masque du texte principal (zone y 500..620)
m=np.zeros((H,W),np.uint8)
m[500:622]=strong[500:622]
k=np.ones((5,5),np.uint8)
m_main=cv2.dilate(m,k,iterations=1)
# 2) masque du reflet = masque du texte retourné autour de A, dilaté
m_ref=np.zeros((H,W),np.uint8)
for y in range(500,622):
    yp=int(round(2*A-y))
    if 0<=yp<H: m_ref[yp]=np.maximum(m_ref[yp],m_main[y])
m_ref[:718]=0
m_ref=cv2.dilate(m_ref,np.ones((5,5),np.uint8),iterations=1)
mask=np.maximum(m_main,m_ref)
inp=cv2.inpaint(img,mask*255,6,cv2.INPAINT_TELEA).astype(float)
# grain : reproduire le bruit local du sol
ring=cv2.dilate(mask,np.ones((25,25),np.uint8))-mask
noise_ref=S[ring>0]-cv2.GaussianBlur(S,(0,0),2)[ring>0]
sd=noise_ref.std(axis=0)
rng=np.random.default_rng(7)
noise=rng.normal(0,1,S.shape)*sd
bg=np.where(mask[...,None]>0,inp+noise*0.8,S)

# 3) rendu du nouveau texte (sur-échantillonné x4)
SS=4
fb=ImageFont.truetype(F+'Montserrat-Bold.ttf',SIZE*SS)
fl=ImageFont.truetype(F+'Montserrat-Regular.ttf',SIZE*SS)
wb=fb.getlength(NEW_BOLD); wl=fl.getlength(NEW_LIGHT)
total=(wb+wl)/SS
x0=703.5-total/2
print('largeur totale',round(total),'x0',round(x0))
def layer(font,txt,x):
    L=Image.new('L',(W*SS,H*SS),0)
    d=ImageDraw.Draw(L)
    d.text((x*SS,BASE*SS),txt,font=font,fill=255,anchor='ls')
    return L
Lb=layer(fb,NEW_BOLD,x0)
Ll=layer(fl,NEW_LIGHT,x0+wb/SS)
def down(L): return np.array(L.resize((W,H),Image.LANCZOS)).astype(float)/255
ab=down(Lb); al=down(Ll)
def comp(base,alpha,color):
    a=alpha[...,None]
    return base*(1-a)+np.array(color,float)*a
out=comp(bg,ab,C_DARK); out=comp(out,al,C_LIGHT)
# 4) reflet : retourner autour de A, opacité décroissante, léger flou
def reflect(a):
    r=np.zeros_like(a)
    for yp in range(int(A)+1,H):
        y=int(round(2*A-yp))
        if 0<=y<H: r[yp]=a[y]
    return r
ys=np.arange(H)
op=np.clip(0.152-0.0013*(ys-734),0.09,0.16)[:,None]
op=np.where(ys[:,None]>=720,op,0)
KB=float(__import__('os').environ.get('KB','1'));KL=float(__import__('os').environ.get('KL','1'))
rb=cv2.GaussianBlur(reflect(ab),(0,0),0.8)*op*KB
rl=cv2.GaussianBlur(reflect(al),(0,0),0.8)*op*KL
out=comp(out,rb,C_DARK); out=comp(out,rl,C_LIGHT)
res=np.clip(out+0.5,0,255).astype(np.uint8)
Image.fromarray(res).convert('RGBA').save(OUT)
# aperçus
old=Image.open(SRC).convert('RGB'); new=Image.fromarray(res)
box=(200,480,1210,768)
pair=Image.new('RGB',(box[2]-box[0],(box[3]-box[1])*2+10),'white')
pair.paste(old.crop(box),(0,0)); pair.paste(new.crop(box),(0,box[3]-box[1]+10))
pair.save('/tmp/compare.png')
print('ok')
