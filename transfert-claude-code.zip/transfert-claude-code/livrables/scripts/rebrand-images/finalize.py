import numpy as np, os, shutil, io
from PIL import Image
ORIG='/home/claude/rc/'; NEWD='/home/claude/rc_new/'
os.makedirs(NEWD,exist_ok=True)
def load(p): return Image.open(p).convert('RGB')
scene_old=load(ORIG+'reine_cloud_full_scene.png')
scene_new=load('/home/claude/rc_out/reine_cloud_full_scene.png')
S_old=np.array(scene_old).astype(float)

# coefficients des variantes (ajustés sur les originaux)
def fit(fname):
    D=np.array(Image.open(ORIG+fname).convert('RGBA')).astype(float)
    co=[]
    for c in range(3):
        x=S_old[...,c].ravel();y=D[...,c].ravel()
        A=np.vstack([x,np.ones_like(x)]).T
        co.append(np.linalg.lstsq(A,y,rcond=None)[0])
    return co, int(np.round(D[...,3].mean()))
variants={}
for f in sorted(os.listdir(ORIG)):
    if f.startswith('web_background_opacity') or f.startswith('web_background_tint') or f.startswith('web_hero'):
        variants[f]=fit(f)

def rgba(arr,alpha):
    a=np.clip(np.rint(arr),0,255).astype(np.uint8)
    out=np.dstack([a,np.full(a.shape[:2],alpha,np.uint8)])
    return Image.fromarray(out,'RGBA')

def pipeline(scene_img):
    S=np.array(scene_img).astype(float); out={}
    out['reine_cloud_full_scene.png']=rgba(S,255)
    for f,(co,alpha) in variants.items():
        arr=np.dstack([S[...,c]*co[c][0]+co[c][1] for c in range(3)])
        out[f]=rgba(arr,alpha)
    # bannières : redimensionnement LANCZOS puis découpe
    b=scene_img.resize((1920,983),Image.LANCZOS).crop((0,191,1920,791)); out['banner_website_1920x600.png']=b.convert('RGBA')
    l=scene_img.resize((1500,819),Image.LANCZOS).crop((0,159,1500,659)); out['banner_linkedin_1500x500.png']=l.convert('RGBA')
    return out

# 1) vérification : le pipeline appliqué à l'ANCIENNE scène doit reproduire les fichiers d'origine
ref=pipeline(scene_old)
print('--- reproductibilité sur l\'ancienne scène (erreur moyenne vs fichiers d\'origine)')
for f,im in ref.items():
    o=np.array(Image.open(ORIG+f).convert('RGBA')).astype(float); n=np.array(im).astype(float)
    print(f, round(np.abs(o-n).mean(),3))
# 2) génération avec la NOUVELLE scène
new=pipeline(scene_new)
for f,im in new.items(): im.save(NEWD+f,optimize=True)
# jpg
scene_new.save(NEWD+'reine_cloud_full_scene.jpg','JPEG',quality=98)
new['banner_website_1920x600.png'].convert('RGB').save(NEWD+'banner_website_1920x600.jpg','JPEG',quality=95)
new['banner_linkedin_1500x500.png'].convert('RGB').save(NEWD+'banner_linkedin_1500x500.jpg','JPEG',quality=95)
# favicons + svg
for f in os.listdir(ORIG):
    if f.startswith('favicon'): shutil.copy(ORIG+f,NEWD+f)
svg=open(ORIG+'reine_cloud_master.svg',encoding='utf-8').read()
assert svg.count('reine.cloud')==1
open(NEWD+'reine_cloud_master.svg','w',encoding='utf-8').write(svg.replace('reine.cloud','reine-cloud.fr'))
# 3) contrôle : différences entre ancien et nouveau confinées à la zone du texte (scène)
d=np.abs(np.array(new['reine_cloud_full_scene.png']).astype(int)-np.array(ref['reine_cloud_full_scene.png']).astype(int)).sum(2)
ys,xs=np.where(d>0); print('scène : pixels modifiés y',ys.min(),ys.max(),'x',xs.min(),xs.max(),'nb',len(ys))
print(sorted(os.listdir(NEWD)))
