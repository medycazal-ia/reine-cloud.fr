# Inventaire des livrables

## Liens publiés sur claude.ai (privés tant que non partagés)
- Présentation interne (planches, 14) : https://claude.ai/artifact/M6VwL9p49znaDuXhiMwRjL
- Présentation client (planches, 8) : https://claude.ai/artifact/J8DGcMC1FWFmQSE2zzDtww
- Page HTML client : https://claude.ai/artifact/4UvMRstsprRfxh6aWz4WBZ
- Page HTML interne (confidentielle) : https://claude.ai/artifact/2A1YQbWUVUTjzEbLaZZLyH

## Fichiers de ce dossier
### livrables/pages-html/
- `offreco-client.html` — page client autonome (8 sections : formules, socle, agent standard, remises, sur mesure, engagement, calculateur d'usage, démarrer/contact). Réglages du calculateur en tête de script : `SEUIL` (0 = « précisé dans le devis »), `TAUX` (0,87), `PRIX` (prix publics).
- `presentation-interne.html` — 14 sections : constat, vigilance lwspanel, économie de la revente, concurrence, marché des agents, verdict, offre, scénario, sur mesure, engagement, heures/renouvellement, remises, calculateur d'API (avec marge de sécurité), vérifications avant lancement. **Confidentiel.**

### livrables/site-offreco/  (pack pour Claude Code)
- `CLAUDE.md`, `PROMPT-A-COLLER.txt`, `LISEZ-MOI.md` ; `public/offreco/index.html` (page client) ; `private/presentation-interne.html` ; `docs/` : `OFFRES-CLIENT.md`, `NOTES-INTERNES.md` (confidentiel), `SECURITE.md`, `A-COMPLETER.md`.

### livrables/logo/reine-cloud-logo-a-plat/
- `svg/` : 9 variantes vectorielles (empilé et horizontal en couleur et fond sombre ; une couleur violet et blanc ; icône seule) — textes convertis en tracés (police Montserrat, licence libre).
- `png/` : exports transparents + aperçus sur fond sombre. `favicons/` : `favicon.ico` + PNG 16 à 512. `LISEZ-MOI.txt` : palette et conseils.

### livrables/pack-branding-image-corrige/
- 24 fichiers du pack d'origine (bannières site et LinkedIn, fonds, scène complète, favicons, SVG maître) avec `reine.cloud` remplacé par `reine-cloud.fr`, reflets à l'envers compris. Les favicons sont inchangés (pas de texte).

### livrables/canvas-sources/
- `interne/` (14 planches + `Offre`, etc.) et `client/` (8 planches) : sources des présentations « planches » (fichiers `.dc.html` + `canvas.json`). Ils dépendent du moteur de la plateforme (`support.js` non inclus) : référence uniquement.

### livrables/scripts/
- `pages-html/` : `base.py` (CSS/JS commun), `client.py`, `internal.py` — régénèrent les deux pages HTML.
- `logo/` : `geom.py`, `build.py`, `mono.py` — régénèrent le logo à plat (nécessitent Python, fontTools, cairosvg, shapely, svgpathtools, et les polices Montserrat).
- `rebrand-images/` : `build_scene.py`, `finalize.py` — régénèrent la scène et toutes les images dérivées.
