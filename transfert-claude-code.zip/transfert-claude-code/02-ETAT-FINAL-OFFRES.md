# État final des offres — référence unique (29 septembre 2026)

Légende : **[U]** = décidé par l'utilisateur ; **[C]** = proposition de Claude adoptée sans objection ; **[H]** = hypothèse de calcul, à confirmer.
Tous les prix sont **nets, sans TVA** (« TVA non applicable, art. 293 B du CGI ») **[U]**.

## PARTIE 1 — Offres et conditions (partie utilisable côté client)

### Le socle — 19,99 € / mois **[U]**
Site et e-mails professionnels, hébergement en France, sauvegardes et mises à jour, interlocuteur unique, **2 révisions par an d'environ 1 heure** (changements rapides et simples) **[U]**. Arguments : moins de 0,70 € par jour ; 239,88 € par an ; un seul prestataire.
> À vérifier : « hébergement en France » et « sauvegardes » doivent correspondre à ce qui est réellement livré **[H]**.

### L'agent standard — 99 € / mois par agent **[U]** (était 69 € puis relevé à 99 €)
- Un agent traite **2 problématiques proches, sur le même outil** ; autre outil ou 3e problématique = autre agent **[U]**.
- Adaptation **gratuite** si le client envoie ses problématiques ; pas de frais de mise en place **[U, confirmé implicitement]**.
- **Audit en visio optionnel** : 1 ou 2 heures, à 49 €/h **[U]**.
- **Aucune heure de suivi incluse** ; modifications et suivi : 49 €/h **[U]**.
- Argument commercial **[U]** : 99 € ≈ environ 4 heures de travail d'un salarié ; si l'agent fait gagner plus de 4 h/mois, il est rentabilisé.
- **Remises** (suivent les agents actifs, y compris ceux ajoutés plus tard) **[U]** :

| Agents | Remise | Prix mensuel | Par agent | Économie sur un an |
|---|---|---|---|---|
| 1 | 0 % | 99,00 € | 99,00 € | — |
| 2 | 0 % | 198,00 € | 99,00 € | — |
| 3 | 20 % | 237,60 € | 79,20 € | 712,80 € |
| 4 | 30 % | 277,20 € | 69,30 € | 1 425,60 € |
| 5 | 40 % | 297,00 € | 59,40 € | 2 376,00 € |
| 6 et plus | sur devis et négociation | | | |

### Le sur mesure **[U]**
- **Abonnement : à partir de 299 € / mois** : suivi/supervision, **rapport mensuel**, **forfait de 2 h de révisions par mois**, **3 interventions maximum**, **non cumulables** (heures perdues en fin de mois).
- **Mise en place : à partir de 1 500 €** (3 niveaux : faible/moyenne/forte, selon outils connectés, sensibilité des données, volume).
- **Cadrage préalable : 199 €**, limité à **3 h** ; au-delà **49 €/h**. Si le client poursuit, **50 % du cadrage (heures en plus comprises) déduits de la mise en place** (99,50 € pour 3 h → mise en place à partir de 1 400,50 €). Exemple 5 h : 297 € de cadrage, remise 148,50 €.
- **À la carte : 49 €/h** (heures hors forfait, nouvelles fonctions, options).
- Au-delà d'un **plafond d'usage** (API/outils) défini au devis, l'excédent est refacturé — **seuil et prix de l'excédent : NON encore fixés** **[C]**.

### Engagement (sur mesure) **[U]**
- **24 mois**. Sortie anticipée : **75 % des mensualités restantes avant 6 mois ; 50 % à partir de 6 mois** (paliers gardés après discussion « engagement ferme »).
- **Renouvellement tacite pour 24 mois**, sauf **préavis de 6 mois avant la fin** (donc avant le mois 18).
- Recette signée ; RGPD ; conditions de reprise fixées au contrat **[C]**.
- Contrat minimum : 24 × 299 = 7 176 € + cadrage 199 € + mise en place 1 400,50 € = **8 775,50 €**.
- Exemples (299 €/mois) : départ après 3 mois → 21 × 299 = 6 279 € × 75 % ≈ 4 709 € ; après 12 mois → 12 × 299 = 3 588 € × 50 % = 1 794 €.

### Tarif horaire unique : 49 € **[U]**

### Calculateur d'usage (client) **[C]**
Prix publics du fournisseur d'IA (page officielle de tarifs, 29/09/2026), USD par million de jetons (lecture / écriture) : **Haiku 4.5 = 1 / 5 ; Sonnet 5.5 = 2 / 10 ; Opus 5.5 = 4 / 20**. Conversion indicative **1 $ = 0,87 €** (cours de fin septembre 2026). Hypothèses **[H]** : 1 page ≈ 1 000 jetons ; consignes de l'agent ≈ 1 500 jetons par étape ; fourchette ×1 à ×1,5. Le seuil inclus sera défini plus tard **[U]**.

### Contact
La Maison du CREL — cazal@medy.site — +33 6 74 20 16 62 (appels et WhatsApp : `https://wa.me/33674201662`) — site : `medy.site/offreco`.

---
## PARTIE 2 — INTERNE ET CONFIDENTIELLE (ne jamais publier)

### Fournisseur d'hébergement
LWS Reseller : S 19,99 € HT (**23,99 € TTC**) 10 comptes cPanel / 60 Go ; M 39,99 € HT 20 / 120 Go ; L 59,99 € HT 30 / 160 Go ; XL 99,99 € HT 40 / 200 Go. Coût par compte ≈ 2 € HT ≈ **2,40 € TTC** (TVA non récupérable). Extras : WHMCS en option, infogérance dès 9,99 € HT l'acte ; matériel Xeon E5 v4 (180 processus) ; reconduction tacite ; satisfait ou remboursé 30 jours. `lwspanel.fr` n'est **pas** l'offre revendeur (domaine enregistré) ; commander uniquement sur lws.fr ; `lwspanel.host` : lien avec LWS non confirmé.

### Marges (calculs)
- Socle : ≈ 17,59 €/client/mois après part de serveur ≈ 211 €/an ≈ 4 h à 50 €/h ; les 2 révisions d'1 h en consomment la moitié.
- Agent 99 € : avec coût d'API d'exemple de 23,40 € par agent → marge 75,60 € (1–2 agents), 55,80 € (3), 45,90 € (4), 36,00 € (5). Une heure non payée à 49 € efface la marge à 5 agents. Plancher de négociation conseillé pour 6+ agents : ≥ prix par agent à 5 agents (59,40 €).
- Sur mesure : 2 h de forfait = 98 € de temps à 49 €/h ; il reste ≈ 201 € sur 299 € pour supervision, rapport et API.
- Cadrage 199 € / 3 h ≈ 66 €/h ; si le client signe, net 99,50 € (≈ 33 €/h) ; heures au-delà de 3 h valent 24,50 €/h nets après remise.
- Scénario illustratif (8 clients : 4 socle, 3 socle+agent à 118,99 €, 1 sur mesure dès 299 €) : ≈ 736 €/mois − serveur 23,99 € ≈ **712 €/mois ≈ 8 500 €/an** + 1 500 € de mise en place ; point mort du serveur : 2 clients socle. Hypothèse, avant outils/API/temps.

### Marché et concurrence (sources web, non toutes vérifiées)
Hébergement : Hostinger ≈ 1,49 €/mois (promo), OVHcloud ≈ 3,59 €, o2switch ≈ 7,99 €. Agents IA : RPA mondial 13,8 Md$ (2026), no-code/IA 19,6 Md$ (projection), 75 % des entreprises > 20 salariés utiliseraient des agents IA d'ici 2027 (McKinsey, cité). Concurrents : plateformes (Mistral Le Chat, Dust, H), agences n8n, freelances, marque blanche. Chances de réussite (estimation qualitative /5) : hébergement seul 1,5 ; agents livrés tels quels 2 ; sur mesure sur une niche 3,5 ; offre combinée en abonnement 4. Niche évoquée : opticiens (tiers payant).

### Vigilances
Juridique (engagement 24 mois, indemnité de sortie = clause pénale modérable, reconduction tacite, particuliers vs professionnels → juriste) ; cohérence (paliers → engagement « ferme » au sens large seulement) ; **franchise en base de TVA** (seuil à vérifier) ; le calculateur client rend visible le rapport coût d'usage (≈ 4,50 €) / prix (99 €) ; marge qui fond avec les remises.
