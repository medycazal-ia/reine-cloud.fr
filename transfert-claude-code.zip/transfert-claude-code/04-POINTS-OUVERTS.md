# Points ouverts (à décider ou à vérifier)

1. **Seuil d'usage** inclus dans les offres et **prix de l'excédent** refacturé (variable `SEUIL` de la page client).
2. **Coûts d'API réels** : mesurer un agent pendant une semaine ; remplacer les valeurs d'exemple (23,40 € par agent).
3. **Juriste** : contrat sur mesure (24 mois, sortie 75 % / 50 %, reconduction tacite, préavis 6 mois, recette, RGPD, réversibilité), CGV éventuelles.
4. **TVA** : seuil de la franchise en base et effet d'un dépassement sur les prix.
5. **Mentions légales** et politique de confidentialité de `medy.site/offreco` (à fournir/valider).
6. **Agent standard** : absence de frais de mise en place et éventuel engagement à confirmer.
7. **Limite de 3 interventions par mois** (forfait de 2 h du sur mesure) : confirmée par l'utilisateur.
8. **Hébergement / sauvegardes** : vérifier que les promesses du socle correspondent à la réalité.
9. **Référencement** de `/offreco` : indexer ou non.
10. **Zone privée** : chemin et mode d'accès pour la présentation interne (réutiliser la protection existante seulement si elle est vérifiée côté serveur ; sinon ne pas l'héberger).
11. **Logo reine-cloud.fr** : valider le logo à plat (couronne, couleur du nom, symbole nuage-orbite), tester le favicon à 16 px ; vérifier la disponibilité de la marque et la protection juridique d'une image générée par IA (INPI/juriste).
12. **Police du logo** : Montserrat utilisée faute de la police d'origine.
